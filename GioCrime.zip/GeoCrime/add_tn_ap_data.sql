-- ============================================================================
-- Add Tamil Nadu & Andhra Pradesh crime data to existing geocrime database
-- Run this ONCE in MySQL Workbench if you already have Karnataka data
-- ============================================================================

USE geocrime;

-- Check current count before inserting
SELECT COUNT(*) AS crimes_before FROM crimes;

-- ── TAMIL NADU ────────────────────────────────────────────────────────────────

-- Chennai
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'High-volume theft in T Nagar commercial zone. 24,500 cases.',   13.0418, 80.2341, 'T Nagar, Chennai, Tamil Nadu',              '2026-01-10 10:00:00', 'HIGH'),
('Assault',     'Assault cases in Adyar residential area. 13,200 cases.',        12.9981, 80.2565, 'Adyar, Chennai, Tamil Nadu',                '2026-01-12 10:00:00', 'HIGH'),
('Cyber Crime', 'Cyber crime surge in Velachery IT corridor. 8,200 cases.',      12.9788, 80.2209, 'Velachery, Chennai, Tamil Nadu',             '2026-01-15 10:00:00', 'HIGH'),
('Robbery',     'Robbery incidents in Perambur area. 3,400 cases.',              13.1143, 80.2329, 'Perambur, Chennai, Tamil Nadu',              '2026-01-17 10:00:00', 'HIGH'),
('Fraud',       'Financial fraud in Anna Nagar, Chennai. 5,100 cases.',          13.0850, 80.2101, 'Anna Nagar, Chennai, Tamil Nadu',            '2026-01-19 10:00:00', 'MEDIUM'),
('Burglary',    'Burglary cases in Tambaram. 2,800 cases.',                      12.9249, 80.1000, 'Tambaram, Chennai, Tamil Nadu',              '2026-01-21 10:00:00', 'MEDIUM'),
('Murder',      'Murder cases in Tondiarpet area. 180 cases.',                   13.1200, 80.2900, 'Tondiarpet, Chennai, Tamil Nadu',            '2026-01-23 10:00:00', 'HIGH');

-- Coimbatore
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Gandhipuram central market. 9,800 cases.',             11.0168, 76.9558, 'Gandhipuram, Coimbatore, Tamil Nadu',        '2026-01-18 10:00:00', 'HIGH'),
('Fraud',       'Financial fraud in Peelamedu business district. 6,400 cases.',  11.0270, 77.0270, 'Peelamedu, Coimbatore, Tamil Nadu',          '2026-01-20 10:00:00', 'MEDIUM'),
('Assault',     'Assault cases in RS Puram, Coimbatore. 4,200 cases.',           11.0050, 76.9600, 'RS Puram, Coimbatore, Tamil Nadu',           '2026-01-24 10:00:00', 'MEDIUM'),
('Cyber Crime', 'Cyber crime in Saibaba Colony, Coimbatore. 3,100 cases.',       11.0300, 76.9700, 'Saibaba Colony, Coimbatore, Tamil Nadu',     '2026-01-26 10:00:00', 'MEDIUM');

-- Madurai
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft cases in Anna Nagar, Madurai. 7,200 cases.',              9.9252,  78.1198, 'Anna Nagar, Madurai, Tamil Nadu',            '2026-01-22 10:00:00', 'HIGH'),
('Assault',     'Assault incidents in KK Nagar, Madurai. 5,300 cases.',          9.9195,  78.1100, 'KK Nagar, Madurai, Tamil Nadu',              '2026-01-25 10:00:00', 'MEDIUM'),
('Robbery',     'Robbery near Mattuthavani bus stand, Madurai. 2,100 cases.',    9.9312,  78.1200, 'Mattuthavani, Madurai, Tamil Nadu',          '2026-01-28 10:00:00', 'HIGH'),
('Fraud',       'Fraud cases in Tallakulam, Madurai. 1,800 cases.',              9.9400,  78.1300, 'Tallakulam, Madurai, Tamil Nadu',            '2026-02-01 10:00:00', 'MEDIUM');

-- Salem
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Shevapet, Salem. 5,600 cases.',                        11.6643, 78.1460, 'Shevapet, Salem, Tamil Nadu',                '2026-01-29 10:00:00', 'HIGH'),
('Assault',     'Assault cases in Suramangalam, Salem. 3,200 cases.',            11.6800, 78.1600, 'Suramangalam, Salem, Tamil Nadu',            '2026-02-03 10:00:00', 'MEDIUM');

-- Trichy
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Srirangam, Trichy. 4,900 cases.',                     10.8650, 78.6930, 'Srirangam, Trichy, Tamil Nadu',              '2026-02-05 10:00:00', 'HIGH'),
('Cyber Crime', 'Cyber crime in Thillai Nagar, Trichy. 2,700 cases.',            10.8300, 78.6900, 'Thillai Nagar, Trichy, Tamil Nadu',          '2026-02-07 10:00:00', 'MEDIUM');

-- Tirunelveli
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Palayamkottai, Tirunelveli. 3,800 cases.',             8.7139,  77.7567, 'Palayamkottai, Tirunelveli, Tamil Nadu',     '2026-02-09 10:00:00', 'MEDIUM'),
('Assault',     'Assault in Melapalayam, Tirunelveli. 2,400 cases.',             8.7200,  77.7400, 'Melapalayam, Tirunelveli, Tamil Nadu',       '2026-02-11 10:00:00', 'MEDIUM');

-- Erode & Vellore
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Fraud',       'Fraud cases in Erode town. 3,100 cases.',                       11.3410, 77.7172, 'Erode Town, Erode, Tamil Nadu',              '2026-02-13 10:00:00', 'MEDIUM'),
('Theft',       'Theft in Katpadi, Vellore. 4,200 cases.',                       12.9700, 79.1400, 'Katpadi, Vellore, Tamil Nadu',               '2026-02-15 10:00:00', 'MEDIUM');

-- ── ANDHRA PRADESH ────────────────────────────────────────────────────────────

-- Visakhapatnam
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Cyber Crime', 'Cyber crime in MVP Colony, Visakhapatnam. 9,100 cases.',        17.7384, 83.2165, 'MVP Colony, Visakhapatnam, Andhra Pradesh',  '2026-01-28 10:00:00', 'HIGH'),
('Theft',       'Theft in Gajuwaka industrial area. 8,700 cases.',               17.6868, 83.2185, 'Gajuwaka, Visakhapatnam, Andhra Pradesh',   '2026-01-30 10:00:00', 'HIGH'),
('Assault',     'Assault in Dwaraka Nagar, Visakhapatnam. 5,200 cases.',         17.7200, 83.3000, 'Dwaraka Nagar, Visakhapatnam, Andhra Pradesh','2026-02-02 10:00:00', 'MEDIUM'),
('Robbery',     'Robbery in Seethammadhara, Visakhapatnam. 3,800 cases.',        17.7300, 83.3100, 'Seethammadhara, Visakhapatnam, Andhra Pradesh','2026-02-04 10:00:00', 'HIGH'),
('Fraud',       'Fraud in Madhurawada, Visakhapatnam. 4,100 cases.',             17.7900, 83.3700, 'Madhurawada, Visakhapatnam, Andhra Pradesh', '2026-02-06 10:00:00', 'MEDIUM');

-- Vijayawada
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Robbery',     'Robbery near Benz Circle, Vijayawada. 7,600 cases.',            16.5062, 80.6480, 'Benz Circle, Vijayawada, Andhra Pradesh',   '2026-02-02 10:00:00', 'HIGH'),
('Fraud',       'Fraud in Governorpet, Vijayawada. 5,400 cases.',                16.5193, 80.6305, 'Governorpet, Vijayawada, Andhra Pradesh',   '2026-02-05 10:00:00', 'MEDIUM'),
('Theft',       'Theft in Patamata, Vijayawada. 6,200 cases.',                   16.5200, 80.6200, 'Patamata, Vijayawada, Andhra Pradesh',      '2026-02-08 10:00:00', 'HIGH'),
('Cyber Crime', 'Cyber crime in Moghalrajpuram, Vijayawada. 3,900 cases.',       16.5100, 80.6400, 'Moghalrajpuram, Vijayawada, Andhra Pradesh','2026-02-10 10:00:00', 'MEDIUM'),
('Assault',     'Assault in Labbipet, Vijayawada. 4,300 cases.',                 16.5000, 80.6300, 'Labbipet, Vijayawada, Andhra Pradesh',      '2026-02-12 10:00:00', 'MEDIUM');

-- Tirupati
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft near Renigunta, Tirupati. 4,200 cases.',                  13.6288, 79.5108, 'Renigunta, Tirupati, Andhra Pradesh',       '2026-02-08 10:00:00', 'MEDIUM'),
('Assault',     'Assault in Balaji Colony, Tirupati. 3,100 cases.',              13.6500, 79.4200, 'Balaji Colony, Tirupati, Andhra Pradesh',   '2026-02-10 10:00:00', 'MEDIUM'),
('Fraud',       'Fraud near Tirumala, Tirupati. 2,600 cases.',                   13.6833, 79.3500, 'Tirumala, Tirupati, Andhra Pradesh',        '2026-02-14 10:00:00', 'MEDIUM');

-- Guntur
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Brodipet, Guntur. 5,800 cases.',                       16.3067, 80.4365, 'Brodipet, Guntur, Andhra Pradesh',          '2026-02-16 10:00:00', 'HIGH'),
('Assault',     'Assault in Arundelpet, Guntur. 3,700 cases.',                   16.3100, 80.4400, 'Arundelpet, Guntur, Andhra Pradesh',        '2026-02-18 10:00:00', 'MEDIUM'),
('Cyber Crime', 'Cyber crime in Nagarampalem, Guntur. 2,900 cases.',             16.3200, 80.4500, 'Nagarampalem, Guntur, Andhra Pradesh',      '2026-02-20 10:00:00', 'MEDIUM');

-- Kurnool
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Kurnool city centre. 4,500 cases.',                    15.8281, 78.0373, 'Kurnool City, Kurnool, Andhra Pradesh',     '2026-02-22 10:00:00', 'HIGH'),
('Robbery',     'Robbery in Bellary Road area, Kurnool. 2,200 cases.',           15.8300, 78.0400, 'Bellary Road, Kurnool, Andhra Pradesh',     '2026-02-24 10:00:00', 'HIGH');

-- Nellore
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Pogathota, Nellore. 3,900 cases.',                     14.4426, 79.9865, 'Pogathota, Nellore, Andhra Pradesh',        '2026-02-26 10:00:00', 'MEDIUM'),
('Fraud',       'Fraud in Magunta Layout, Nellore. 2,100 cases.',                14.4500, 79.9900, 'Magunta Layout, Nellore, Andhra Pradesh',   '2026-02-28 10:00:00', 'MEDIUM');

-- Kadapa
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Kadapa city. 3,200 cases.',                            14.4673, 78.8242, 'Kadapa City, Kadapa, Andhra Pradesh',       '2026-03-01 10:00:00', 'MEDIUM'),
('Assault',     'Assault in Rajampet, Kadapa. 1,900 cases.',                     14.1900, 79.1600, 'Rajampet, Kadapa, Andhra Pradesh',          '2026-03-03 10:00:00', 'MEDIUM');

-- Anantapur
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',       'Theft in Anantapur town. 3,600 cases.',                         14.6819, 77.6006, 'Anantapur Town, Anantapur, Andhra Pradesh', '2026-03-05 10:00:00', 'MEDIUM'),
('Fraud',       'Fraud in Hindupur, Anantapur. 1,700 cases.',                    13.8300, 77.4900, 'Hindupur, Anantapur, Andhra Pradesh',       '2026-03-07 10:00:00', 'LOW');

-- Verify final count
SELECT COUNT(*) AS total_crimes FROM crimes;
SELECT type, COUNT(*) AS count FROM crimes GROUP BY type ORDER BY count DESC;
