package com.example.geocrime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeoCrimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
