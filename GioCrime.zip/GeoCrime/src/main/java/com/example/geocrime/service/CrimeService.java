package com.example.geocrime.service;

import com.example.geocrime.model.Crime;
import com.example.geocrime.model.CrimeEvent;
import com.example.geocrime.repository.CrimeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class CrimeService {

    @Autowired
    private CrimeRepository repo;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    // ── CRUD ──────────────────────────────────────────────────────────────────

    public List<Crime> getAllCrimes() {
        return repo.findAll();
    }

    public Optional<Crime> getCrimeById(int id) {
        return repo.findById(id);
    }

    public Crime saveCrime(Crime crime) {
        boolean isNew = crime.getCrimeId() == 0;
        if (crime.getCrimeDate() == null) {
            crime.setCrimeDate(LocalDateTime.now());
        }
        if (crime.getSeverity() == null || crime.getSeverity().isBlank()) {
            crime.setSeverity("MEDIUM");
        }
        Crime saved = repo.save(crime);

        // Broadcast real-time event to all WebSocket subscribers
        String action = isNew ? "ADDED" : "UPDATED";
        messagingTemplate.convertAndSend("/topic/crimes", new CrimeEvent(action, saved));

        return saved;
    }

    public void deleteCrime(int id) {
        repo.deleteById(id);
        // Broadcast deletion event
        messagingTemplate.convertAndSend("/topic/crimes", new CrimeEvent("DELETED", id));
    }

    public List<Crime> filterCrimes(String type, String location,
                                     LocalDateTime startDate, LocalDateTime endDate) {
        return repo.filterCrimes(
            (type     != null && type.isBlank())     ? null : type,
            (location != null && location.isBlank()) ? null : location,
            startDate,
            endDate
        );
    }

    // ── Analytics ─────────────────────────────────────────────────────────────

    public Map<String, Object> getAnalytics() {
        Map<String, Object> analytics = new LinkedHashMap<>();

        analytics.put("total", repo.count());

        // By type
        Map<String, Long> typeMap = new LinkedHashMap<>();
        for (Object[] row : repo.countByType()) {
            typeMap.put((String) row[0], (Long) row[1]);
        }
        analytics.put("byType", typeMap);

        // By location (top 10)
        Map<String, Long> locationMap = new LinkedHashMap<>();
        List<Object[]> byLocation = repo.countByLocation();
        for (int i = 0; i < Math.min(byLocation.size(), 10); i++) {
            Object[] row = byLocation.get(i);
            locationMap.put((String) row[0], (Long) row[1]);
        }
        analytics.put("byLocation", locationMap);

        // Monthly trend
        List<Map<String, Object>> monthTrend = new ArrayList<>();
        for (Object[] row : repo.countByMonth()) {
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("year",  row[0]);
            entry.put("month", row[1]);
            entry.put("count", row[2]);
            monthTrend.add(entry);
        }
        analytics.put("monthlyTrend", monthTrend);

        // By severity
        Map<String, Long> severityMap = new LinkedHashMap<>();
        for (Object[] row : repo.countBySeverity()) {
            severityMap.put(row[0] != null ? (String) row[0] : "UNKNOWN", (Long) row[1]);
        }
        analytics.put("bySeverity", severityMap);

        return analytics;
    }
}
