-- ============================================================================
-- Tamil Nadu & Andhra Pradesh Crime Dataset
-- Run this in MySQL Workbench against the geocrime database
-- ============================================================================

USE geocrime;

-- Tamil Nadu - Chennai
INSERT INTO crimes (type, description, latitude, longitude, location_name, crime_date, severity) VALUES
('Theft',      'High-volume theft incidents in T Nagar commercial zone. 24500 cases reported.',      13.0418, 80.2341, 'T Nagar, Chennai, Tamil Nadu',        '2026-01-10 10:00:00', 'HIGH'),
('Assault',    'Assault cases reported in Adyar residential area. 13200 cases recorded.',            12.9981, 80.2565, 'Adyar, Chennai, Tamil Nadu',           '2026-01-12 14:00:00', 'HIGH'),
('Cyber Crime','Cyber crime surge in Velachery IT corridor. 8200 cases reported.',                   12.9788, 80.2209, 'Velachery, Chennai, Tamil Nadu',        '2026-01-15 11:00:00', 'HIGH'),

-- Tamil Nadu - Coimbatore
('Theft',      'Theft incidents in Gandhipuram central market area. 9800 cases reported.',           11.0168, 76.9558, 'Gandhipuram, Coimbatore, Tamil Nadu',   '2026-01-18 09:30:00', 'HIGH'),
('Fraud',      'Financial fraud cases in Peelamedu business district. 6400 cases reported.',         11.0270, 77.0270, 'Peelamedu, Coimbatore, Tamil Nadu',     '2026-01-20 13:00:00', 'MEDIUM'),

-- Tamil Nadu - Madurai
('Theft',      'Theft cases in Anna Nagar, Madurai. 7200 cases reported.',                          9.9252,  78.1198, 'Anna Nagar, Madurai, Tamil Nadu',       '2026-01-22 10:00:00', 'HIGH'),
('Assault',    'Assault incidents in KK Nagar, Madurai. 5300 cases reported.',                      9.9195,  78.1100, 'KK Nagar, Madurai, Tamil Nadu',         '2026-01-25 16:00:00', 'MEDIUM'),

-- Andhra Pradesh - Visakhapatnam
('Cyber Crime','Cyber crime cases in MVP Colony, Visakhapatnam. 9100 cases reported.',              17.7384, 83.2165, 'MVP Colony, Visakhapatnam, Andhra Pradesh', '2026-01-28 11:00:00', 'HIGH'),
('Theft',      'Theft incidents in Gajuwaka industrial area, Visakhapatnam. 8700 cases reported.',  17.6868, 83.2185, 'Gajuwaka, Visakhapatnam, Andhra Pradesh',   '2026-01-30 09:00:00', 'HIGH'),

-- Andhra Pradesh - Vijayawada
('Robbery',    'Robbery cases near Benz Circle, Vijayawada. 7600 cases reported.',                  16.5062, 80.6480, 'Benz Circle, Vijayawada, Andhra Pradesh',   '2026-02-02 20:00:00', 'HIGH'),
('Fraud',      'Fraud cases in Governorpet, Vijayawada. 5400 cases reported.',                      16.5193, 80.6305, 'Governorpet, Vijayawada, Andhra Pradesh',   '2026-02-05 14:00:00', 'MEDIUM'),

-- Andhra Pradesh - Tirupati
('Theft',      'Theft incidents near Renigunta, Tirupati. 4200 cases reported.',                    13.6288, 79.5108, 'Renigunta, Tirupati, Andhra Pradesh',       '2026-02-08 10:00:00', 'MEDIUM'),
('Assault',    'Assault cases in Balaji Colony, Tirupati. 3100 cases reported.',                    13.6500, 79.4200, 'Balaji Colony, Tirupati, Andhra Pradesh',   '2026-02-10 17:00:00', 'MEDIUM');

-- Verify
SELECT COUNT(*) AS total_crimes FROM crimes;
SELECT location_name, type, severity FROM crimes ORDER BY crime_id DESC LIMIT 15;
