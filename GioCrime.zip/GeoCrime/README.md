# GeoCrime - Crime Visualization & Analytics Platform

A modern full-stack web application for visualizing and analyzing crime data with real-time updates, interactive maps, and comprehensive analytics.

## 🚀 Features

### Core Features
- **Interactive Crime Map** - Visualize crimes on an interactive map with clustering and heatmap support
- **Real-time Updates** - WebSocket-based live crime data updates
- **Advanced Analytics** - Charts and statistics for crime trends, types, locations, and severity
- **Filtering & Search** - Filter crimes by type, location, date range, and severity
- **Admin Panel** - Full CRUD operations for managing crime records
- **User Authentication** - Secure login with role-based access (ADMIN/USER)
- **Responsive Design** - Dark theme with neon accents and glassmorphism effects

### Technical Features
- RESTful API with Spring Boot
- WebSocket integration for real-time updates
- MySQL database with optimized indexes
- BCrypt password encryption
- Leaflet.js for interactive maps
- Chart.js for data visualization
- Vanilla JavaScript (no framework dependencies)

## 🛠️ Tech Stack

### Backend
- **Java 17+** (Spring Boot 3.x)
- **Spring Security** - Authentication & Authorization
- **Spring Data JPA** - Database ORM
- **Spring WebSocket** - Real-time communication
- **MySQL** - Relational database
- **Maven** - Build tool

### Frontend
- **HTML5/CSS3** - Structure & styling
- **Vanilla JavaScript** - No framework dependencies
- **Leaflet.js** - Interactive maps with clustering & heatmap
- **Chart.js** - Data visualization
- **SockJS + STOMP** - WebSocket client

## 📋 Prerequisites

- **Java 17 or higher** - [Download](https://adoptium.net/)
- **MySQL 8.0+** - [Download](https://dev.mysql.com/downloads/)
- **Maven 3.6+** - (Included via Maven Wrapper)
- **Git** - [Download](https://git-scm.com/)

## 🔧 Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd GeoCrime
```

### 2. Setup MySQL Database

#### Create Database
```sql
CREATE DATABASE geocrime CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

#### Create MySQL User (Optional)
```sql
CREATE USER 'geocrime_user'@'localhost' IDENTIFIED BY 'Nagendra@123';
GRANT ALL PRIVILEGES ON geocrime.* TO 'geocrime_user'@'localhost';
FLUSH PRIVILEGES;
```

#### Import Schema & Sample Data
```bash
mysql -u root -p geocrime < src/main/resources/schema.sql
```

Or manually execute the SQL file in MySQL Workbench/phpMyAdmin.

### 3. Configure Application

Edit `src/main/resources/application.properties`:

```properties
# Database Configuration
spring.datasource.url=jdbc:mysql://localhost:3306/geocrime?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=Nagendra@123

# JPA Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=false
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect

# Server Configuration
server.port=8080

# WebSocket Configuration
spring.websocket.allowed-origins=*
```

**Important:** Update the database password to match your MySQL root password.

### 4. Build the Project

#### Windows
```bash
mvnw.cmd clean install
```

#### Linux/Mac
```bash
./mvnw clean install
```

### 5. Run the Application

#### Windows
```bash
mvnw.cmd spring-boot:run
```

#### Linux/Mac
```bash
./mvnw spring-boot:run
```

The application will start on `http://localhost:8080`

## 🎯 Usage

### Access the Application

1. **User Dashboard**: `http://localhost:8080/index.html`
2. **Admin Panel**: `http://localhost:8080/admin.html`
3. **Login Page**: `http://localhost:8080/user-login.html`

### Default Accounts

| Username | Password  | Role  |
|----------|-----------|-------|
| admin    | admin123  | ADMIN |
| user     | user123   | USER  |

### User Dashboard Features

- **Dashboard** - Overview statistics and charts
- **Crime Map** - Interactive map with filters and heatmap
- **Analytics** - Detailed charts and trends
- **Alerts** - High-crime zone warnings
- **Crime List** - Searchable table of all crimes

### Admin Panel Features

- **Overview** - Admin statistics dashboard
- **Add Crime** - Create new crime records with map picker
- **Manage Crimes** - Edit/delete existing records
- **Live Map** - Real-time crime visualization

## 📊 Database Schema

### Users Table
```sql
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Crimes Table
```sql
CREATE TABLE crimes (
    crime_id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    location VARCHAR(255) NOT NULL,
    crime_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    severity VARCHAR(20) DEFAULT 'MEDIUM',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## 🔌 API Endpoints

### Public Endpoints
- `POST /api/users/register` - Register new user

### Authenticated Endpoints (USER/ADMIN)
- `GET /api/crimes` - Get all crimes
- `GET /api/crimes/{id}` - Get crime by ID
- `GET /api/crimes/filter` - Filter crimes (query params: type, location, startDate, endDate)
- `GET /api/crimes/analytics` - Get analytics data

### Admin-Only Endpoints
- `POST /api/crimes` - Create new crime
- `PUT /api/crimes/{id}` - Update crime
- `DELETE /api/crimes/{id}` - Delete crime

### WebSocket Endpoint
- `ws://localhost:8080/ws` - WebSocket connection
- Subscribe to: `/topic/crimes` - Receive real-time crime updates

## 🎨 UI Features

### Dark Theme
- Charcoal background (#0f0f1e)
- Neon accents (red, orange, blue, purple, green)
- Glassmorphism cards with backdrop blur
- Smooth animations and transitions

### Interactive Elements
- Animated stat counters
- Hover effects on cards and buttons
- Toast notifications for actions
- Modal dialogs for editing
- Loading spinners

### Map Features
- Marker clustering for better performance
- Heatmap visualization
- Color-coded crime types
- Popup details on marker click
- Click-to-set coordinates in admin panel

## 🔒 Security

- **BCrypt Password Hashing** - Secure password storage
- **Spring Security** - Authentication & authorization
- **Role-Based Access Control** - ADMIN/USER roles
- **CSRF Protection** - Enabled for form submissions
- **SQL Injection Prevention** - Parameterized queries via JPA

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Change port in application.properties
server.port=8081
```

### Database Connection Failed
- Verify MySQL is running: `mysql -u root -p`
- Check credentials in `application.properties`
- Ensure database `geocrime` exists

### WebSocket Connection Failed
- Check firewall settings
- Verify `spring.websocket.allowed-origins` in properties
- Clear browser cache and reload

### Eclipse Compilation Errors
1. Right-click project → Maven → Update Project
2. Project → Clean → Clean All Projects
3. Restart Eclipse IDE

## 📦 Sample Data

The application includes 53 sample crime records from Karnataka state:
- **Bangalore** - 20 records
- **Mysore** - 10 records
- **Hubli** - 8 records
- **Mangalore** - 7 records
- **Belgaum** - 5 records
- **Davangere** - 3 records

Crime types include: Theft, Assault, Robbery, Burglary, Vandalism, Fraud, Murder, Kidnapping, Cyber Crime

## 🚀 Deployment

### Build Production JAR
```bash
mvnw clean package -DskipTests
```

The JAR file will be in `target/geocrime-0.0.1-SNAPSHOT.jar`

### Run Production JAR
```bash
java -jar target/geocrime-0.0.1-SNAPSHOT.jar
```

### Environment Variables
```bash
export SPRING_DATASOURCE_URL=jdbc:mysql://your-db-host:3306/geocrime
export SPRING_DATASOURCE_USERNAME=your-username
export SPRING_DATASOURCE_PASSWORD=your-password
```

## 📝 License

This project is licensed under the MIT License.

## 👥 Contributors

- **Developer** - Full-stack development
- **Designer** - UI/UX design

## 📧 Support

For issues and questions, please open an issue on GitHub.

---

**Built with ❤️ using Spring Boot & Vanilla JavaScript**
