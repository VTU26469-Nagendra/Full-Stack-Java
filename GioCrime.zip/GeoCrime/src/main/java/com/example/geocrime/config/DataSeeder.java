﻿package com.example.geocrime.config;

import com.example.geocrime.model.Crime;
import com.example.geocrime.model.User;
import com.example.geocrime.repository.CrimeRepository;
import com.example.geocrime.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Seeds crime data and default users on startup.
 * - Users: admin/admin123 (ADMIN) and user/user123 (USER) — created if missing
 * - Karnataka data: inserted only when DB is completely empty
 * - TN/AP data: inserted whenever it is missing (safe to re-run)
 * - NCRB multi-state data: inserted whenever Mumbai data is missing
 */
@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired
    private CrimeRepository repo;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Always ensure default users exist
        seedUsers();
        long total = repo.count();

        if (total == 0) {
            System.out.println("[DataSeeder] Empty DB — seeding all data.");
            seedKarnataka();
        } else {
            System.out.println("[DataSeeder] Found " + total + " existing records.");
        }

        // Always check and insert TN/AP data if missing
        boolean hasTN = !repo.findByLocationContainingIgnoreCase("Tamil Nadu").isEmpty();
        boolean hasAP = !repo.findByLocationContainingIgnoreCase("Andhra Pradesh").isEmpty();

        if (!hasTN || !hasAP) {
            System.out.println("[DataSeeder] TN/AP data missing — inserting now.");
            seedTamilNadu();
            seedAndhraPradesh();
            System.out.println("[DataSeeder] TN/AP data inserted. Total: " + repo.count());
        } else {
            System.out.println("[DataSeeder] TN/AP data already present — skipping.");
        }

        // Always check and insert NCRB multi-state data if missing
        boolean hasNCRB = !repo.findByLocationContainingIgnoreCase("Mumbai").isEmpty();
        if (!hasNCRB) {
            System.out.println("[DataSeeder] NCRB data missing — inserting now.");
            seedNCRBMaharashtra();
            seedNCRBUttarPradesh();
            seedNCRBRajasthan();
            seedNCRBDelhi();
            seedNCRBMadhyaPradesh();
            seedNCRBGujarat();
            seedNCRBWestBengal();
            seedNCRBTelangana();
            seedNCRBKerala();
            seedNCRBPunjab();
            seedNCRBHaryana();
            System.out.println("[DataSeeder] NCRB data inserted. Total: " + repo.count());
        } else {
            System.out.println("[DataSeeder] NCRB data already present — skipping.");
        }

        // Always check and insert NCRB Victim data (Table 1-10) if missing
        boolean hasVictimData = !repo.findByLocationContainingIgnoreCase("Avadi").isEmpty();
        if (!hasVictimData) {
            System.out.println("[DataSeeder] NCRB Victim data (Table 1-10) missing — inserting now.");
            seedNCRBVictimDataKarnataka();
            seedNCRBVictimDataTelangana();
            seedNCRBVictimDataTamilNadu();
            seedNCRBVictimDataWestBengal();
            seedNCRBVictimDataRajasthan();
            seedNCRBVictimDataMadhyaPradesh2();
            seedNCRBVictimDataUttarPradesh2();
            seedNCRBVictimDataGujarat2();
            seedNCRBVictimDataDelhi2();
            seedNCRBVictimDataMaharashtra2();
            System.out.println("[DataSeeder] NCRB Victim data inserted. Total: " + repo.count());
        } else {
            System.out.println("[DataSeeder] NCRB Victim data already present — skipping.");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DEFAULT USERS — admin/admin123 (ADMIN) and user/user123 (USER)
    // ══════════════════════════════════════════════════════════════════════════
    private void seedUsers() {
        upsertUser("Nagendra", "Nagendra@123", "ADMIN");
        upsertUser("user",     "user123",      "USER");
    }

    /**
     * Creates the user if missing, OR resets the password if already exists.
     * Ensures default credentials always work regardless of what is in the DB.
     */
    private void upsertUser(String username, String rawPassword, String role) {
        String encoded = passwordEncoder.encode(rawPassword);
        userRepo.findByUsername(username).ifPresentOrElse(
            existing -> {
                existing.setPassword(encoded);
                existing.setRole(role);
                userRepo.save(existing);
                System.out.println("[DataSeeder] Reset password for: " + username);
            },
            () -> {
                User u = new User();
                u.setUsername(username);
                u.setPassword(encoded);
                u.setRole(role);
                userRepo.save(u);
                System.out.println("[DataSeeder] Created user: " + username + " (role=" + role + ")");
            }
        );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // KARNATAKA (53 records)
    // ══════════════════════════════════════════════════════════════════════════
    private void seedKarnataka() {
        List<Crime> list = new ArrayList<>();

        // Bangalore — 20
        list.add(c("Theft",       "Mobile phone theft near metro station",    12.9716, 77.5946, "MG Road, Bangalore",          "2026-01-15T14:30:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Online banking fraud reported",             12.9352, 77.6245, "Koramangala, Bangalore",       "2026-01-18T10:15:00", "HIGH"));
        list.add(c("Assault",     "Physical altercation outside bar",          12.9698, 77.7499, "Whitefield, Bangalore",        "2026-01-20T23:45:00", "HIGH"));
        list.add(c("Burglary",    "House break-in during daytime",             13.0358, 77.5970, "Yelahanka, Bangalore",         "2026-01-22T11:00:00", "HIGH"));
        list.add(c("Theft",       "Two-wheeler theft from parking lot",        12.9141, 77.6411, "BTM Layout, Bangalore",        "2026-01-25T16:20:00", "MEDIUM"));
        list.add(c("Fraud",       "Real estate fraud case filed",              12.9279, 77.6271, "HSR Layout, Bangalore",        "2026-01-28T09:30:00", "HIGH"));
        list.add(c("Vandalism",   "Public property damage reported",           12.9634, 77.6401, "Indiranagar, Bangalore",       "2026-02-01T02:15:00", "LOW"));
        list.add(c("Robbery",     "Armed robbery at jewelry store",            12.9716, 77.5946, "Commercial Street, Bangalore", "2026-02-03T19:30:00", "HIGH"));
        list.add(c("Kidnapping",  "Minor child kidnapping case",               13.0827, 77.5877, "Hebbal, Bangalore",            "2026-02-05T15:45:00", "HIGH"));
        list.add(c("Theft",       "Laptop theft from office premises",         12.9352, 77.6245, "Koramangala, Bangalore",       "2026-02-08T18:00:00", "MEDIUM"));
        list.add(c("Assault",     "Domestic violence case reported",           12.9141, 77.6411, "BTM Layout, Bangalore",        "2026-02-10T21:30:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Social media account hacking",              12.9698, 77.7499, "Whitefield, Bangalore",        "2026-02-12T13:20:00", "MEDIUM"));
        list.add(c("Burglary",    "Shop break-in at night",                    12.9279, 77.6271, "HSR Layout, Bangalore",        "2026-02-14T03:45:00", "HIGH"));
        list.add(c("Theft",       "Gold chain snatching incident",             12.9716, 77.5946, "MG Road, Bangalore",           "2026-02-16T12:00:00", "HIGH"));
        list.add(c("Fraud",       "Credit card fraud detected",                12.9634, 77.6401, "Indiranagar, Bangalore",       "2026-02-18T10:30:00", "MEDIUM"));
        list.add(c("Vandalism",   "Vehicle vandalism in parking area",         13.0358, 77.5970, "Yelahanka, Bangalore",         "2026-02-20T01:15:00", "LOW"));
        list.add(c("Robbery",     "Street robbery near bus stop",              12.9141, 77.6411, "BTM Layout, Bangalore",        "2026-02-22T20:45:00", "HIGH"));
        list.add(c("Theft",       "Bicycle theft from residential area",       12.9352, 77.6245, "Koramangala, Bangalore",       "2026-02-24T07:30:00", "LOW"));
        list.add(c("Assault",     "Road rage incident reported",               12.9698, 77.7499, "Whitefield, Bangalore",        "2026-02-26T17:00:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Phishing scam targeting seniors",           12.9279, 77.6271, "HSR Layout, Bangalore",        "2026-02-28T11:45:00", "HIGH"));

        // Mysore — 10
        list.add(c("Theft",       "Tourist bag theft near palace",             12.3052, 76.6550, "Mysore Palace Area, Mysore",   "2026-01-16T15:00:00", "MEDIUM"));
        list.add(c("Burglary",    "Residential burglary reported",             12.2958, 76.6394, "Vijayanagar, Mysore",          "2026-01-21T04:30:00", "HIGH"));
        list.add(c("Assault",     "Bar fight escalated to assault",            12.3051, 76.6553, "Devaraja Market, Mysore",      "2026-01-26T22:00:00", "MEDIUM"));
        list.add(c("Theft",       "Auto-rickshaw theft case",                  12.2711, 76.6411, "Hebbal, Mysore",               "2026-02-02T08:15:00", "MEDIUM"));
        list.add(c("Fraud",       "Insurance fraud investigation",             12.3052, 76.6550, "Saraswathipuram, Mysore",      "2026-02-07T14:30:00", "HIGH"));
        list.add(c("Vandalism",   "Graffiti on public walls",                  12.2958, 76.6394, "Kuvempunagar, Mysore",         "2026-02-11T01:00:00", "LOW"));
        list.add(c("Robbery",     "Petrol pump robbery attempt",               12.3051, 76.6553, "Ring Road, Mysore",            "2026-02-15T23:30:00", "HIGH"));
        list.add(c("Theft",       "Mobile phone snatching",                    12.2711, 76.6411, "Chamundi Hill Road, Mysore",   "2026-02-19T16:45:00", "MEDIUM"));
        list.add(c("Assault",     "Workplace assault incident",                12.3052, 76.6550, "Industrial Area, Mysore",      "2026-02-23T10:00:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Online shopping fraud",                     12.2958, 76.6394, "Gokulam, Mysore",              "2026-02-27T12:30:00", "MEDIUM"));

        // Hubli — 8
        list.add(c("Theft",       "Shop theft during business hours",          15.3647, 75.1240, "Old Hubli, Hubli",             "2026-01-17T13:00:00", "MEDIUM"));
        list.add(c("Burglary",    "Warehouse break-in",                        15.3173, 75.1240, "Gokul Road, Hubli",            "2026-01-23T02:45:00", "HIGH"));
        list.add(c("Assault",     "Street fight reported",                     15.3647, 75.1240, "Unkal Lake Area, Hubli",       "2026-01-29T19:15:00", "MEDIUM"));
        list.add(c("Theft",       "Vehicle parts theft",                       15.3173, 75.1240, "Vidyanagar, Hubli",            "2026-02-04T05:30:00", "MEDIUM"));
        list.add(c("Fraud",       "Land fraud case filed",                     15.3647, 75.1240, "Navanagar, Hubli",             "2026-02-09T11:00:00", "HIGH"));
        list.add(c("Robbery",     "Bank ATM robbery attempt",                  15.3173, 75.1240, "Keshwapur, Hubli",             "2026-02-13T22:45:00", "HIGH"));
        list.add(c("Vandalism",   "Bus stop vandalism",                        15.3647, 75.1240, "Hosur, Hubli",                 "2026-02-17T03:00:00", "LOW"));
        list.add(c("Theft",       "Cattle theft from farm",                    15.3173, 75.1240, "Amargol, Hubli",               "2026-02-21T06:15:00", "MEDIUM"));

        // Mangalore — 7
        list.add(c("Theft",       "Beach visitor belongings theft",            12.9141, 74.8560, "Panambur Beach, Mangalore",    "2026-01-19T17:30:00", "MEDIUM"));
        list.add(c("Burglary",    "Hotel room burglary",                       12.8698, 74.8430, "Hampankatta, Mangalore",       "2026-01-24T03:15:00", "HIGH"));
        list.add(c("Assault",     "Pub assault incident",                      12.9141, 74.8560, "Kadri, Mangalore",             "2026-01-30T23:00:00", "MEDIUM"));
        list.add(c("Theft",       "Fishing equipment theft",                   12.8698, 74.8430, "Bunder, Mangalore",            "2026-02-06T07:45:00", "LOW"));
        list.add(c("Fraud",       "Export-import fraud case",                  12.9141, 74.8560, "Port Area, Mangalore",         "2026-02-11T15:00:00", "HIGH"));
        list.add(c("Robbery",     "Jewelry shop robbery",                      12.8698, 74.8430, "Car Street, Mangalore",        "2026-02-16T18:30:00", "HIGH"));
        list.add(c("Cyber Crime", "Email phishing scam",                       12.9141, 74.8560, "Bejai, Mangalore",             "2026-02-25T09:00:00", "MEDIUM"));

        // Belgaum — 5
        list.add(c("Theft",       "Market area pickpocketing",                 15.8497, 74.4977, "Khade Bazaar, Belgaum",        "2026-01-27T14:00:00", "MEDIUM"));
        list.add(c("Burglary",    "Office burglary at night",                  15.8497, 74.4977, "Tilakwadi, Belgaum",           "2026-02-01T04:00:00", "HIGH"));
        list.add(c("Assault",     "Political rally violence",                  15.8497, 74.4977, "Congress Bhavan Area, Belgaum","2026-02-08T16:30:00", "HIGH"));
        list.add(c("Theft",       "Agricultural equipment theft",              15.8497, 74.4977, "Hindalga, Belgaum",            "2026-02-14T06:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Cooperative bank fraud",                    15.8497, 74.4977, "Camp Area, Belgaum",           "2026-02-20T10:30:00", "HIGH"));

        // Davangere — 3
        list.add(c("Theft",       "Cotton bales theft from godown",            14.4644, 75.9218, "APMC Yard, Davangere",         "2026-02-03T05:00:00", "HIGH"));
        list.add(c("Burglary",    "Residential break-in",                      14.4644, 75.9218, "PJ Extension, Davangere",      "2026-02-12T02:30:00", "HIGH"));
        list.add(c("Assault",     "Family dispute turned violent",             14.4644, 75.9218, "Shamanur Road, Davangere",     "2026-02-22T20:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] Karnataka: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // TAMIL NADU (23 records)
    // ══════════════════════════════════════════════════════════════════════════
    private void seedTamilNadu() {
        List<Crime> list = new ArrayList<>();

        // Chennai
        list.add(c("Theft",       "High-volume theft in T Nagar commercial zone. 24,500 cases.",   13.0418, 80.2341, "T Nagar, Chennai, Tamil Nadu",              "2026-01-10T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault cases in Adyar residential area. 13,200 cases.",        12.9981, 80.2565, "Adyar, Chennai, Tamil Nadu",                "2026-01-12T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime surge in Velachery IT corridor. 8,200 cases.",      12.9788, 80.2209, "Velachery, Chennai, Tamil Nadu",             "2026-01-15T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery incidents in Perambur area. 3,400 cases.",              13.1143, 80.2329, "Perambur, Chennai, Tamil Nadu",              "2026-01-17T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Financial fraud in Anna Nagar, Chennai. 5,100 cases.",          13.0850, 80.2101, "Anna Nagar, Chennai, Tamil Nadu",            "2026-01-19T10:00:00", "MEDIUM"));
        list.add(c("Burglary",    "Burglary cases in Tambaram. 2,800 cases.",                      12.9249, 80.1000, "Tambaram, Chennai, Tamil Nadu",              "2026-01-21T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder cases in Tondiarpet area. 180 cases.",                   13.1200, 80.2900, "Tondiarpet, Chennai, Tamil Nadu",            "2026-01-23T10:00:00", "HIGH"));

        // Coimbatore
        list.add(c("Theft",       "Theft in Gandhipuram central market. 9,800 cases.",             11.0168, 76.9558, "Gandhipuram, Coimbatore, Tamil Nadu",        "2026-01-18T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Financial fraud in Peelamedu business district. 6,400 cases.",  11.0270, 77.0270, "Peelamedu, Coimbatore, Tamil Nadu",          "2026-01-20T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault cases in RS Puram, Coimbatore. 4,200 cases.",           11.0050, 76.9600, "RS Puram, Coimbatore, Tamil Nadu",           "2026-01-24T10:00:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Cyber crime in Saibaba Colony, Coimbatore. 3,100 cases.",       11.0300, 76.9700, "Saibaba Colony, Coimbatore, Tamil Nadu",     "2026-01-26T10:00:00", "MEDIUM"));

        // Madurai
        list.add(c("Theft",       "Theft cases in Anna Nagar, Madurai. 7,200 cases.",              9.9252,  78.1198, "Anna Nagar, Madurai, Tamil Nadu",            "2026-01-22T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault incidents in KK Nagar, Madurai. 5,300 cases.",          9.9195,  78.1100, "KK Nagar, Madurai, Tamil Nadu",              "2026-01-25T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery near Mattuthavani bus stand, Madurai. 2,100 cases.",    9.9312,  78.1200, "Mattuthavani, Madurai, Tamil Nadu",          "2026-01-28T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud cases in Tallakulam, Madurai. 1,800 cases.",              9.9400,  78.1300, "Tallakulam, Madurai, Tamil Nadu",            "2026-02-01T10:00:00", "MEDIUM"));

        // Salem
        list.add(c("Theft",       "Theft in Shevapet, Salem. 5,600 cases.",                        11.6643, 78.1460, "Shevapet, Salem, Tamil Nadu",                "2026-01-29T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault cases in Suramangalam, Salem. 3,200 cases.",            11.6800, 78.1600, "Suramangalam, Salem, Tamil Nadu",            "2026-02-03T10:00:00", "MEDIUM"));

        // Trichy
        list.add(c("Theft",       "Theft in Srirangam, Trichy. 4,900 cases.",                     10.8650, 78.6930, "Srirangam, Trichy, Tamil Nadu",              "2026-02-05T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Thillai Nagar, Trichy. 2,700 cases.",            10.8300, 78.6900, "Thillai Nagar, Trichy, Tamil Nadu",          "2026-02-07T10:00:00", "MEDIUM"));

        // Tirunelveli
        list.add(c("Theft",       "Theft in Palayamkottai, Tirunelveli. 3,800 cases.",             8.7139,  77.7567, "Palayamkottai, Tirunelveli, Tamil Nadu",     "2026-02-09T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Melapalayam, Tirunelveli. 2,400 cases.",             8.7200,  77.7400, "Melapalayam, Tirunelveli, Tamil Nadu",       "2026-02-11T10:00:00", "MEDIUM"));

        // Erode & Vellore
        list.add(c("Fraud",       "Fraud cases in Erode town. 3,100 cases.",                       11.3410, 77.7172, "Erode Town, Erode, Tamil Nadu",              "2026-02-13T10:00:00", "MEDIUM"));
        list.add(c("Theft",       "Theft in Katpadi, Vellore. 4,200 cases.",                       12.9700, 79.1400, "Katpadi, Vellore, Tamil Nadu",               "2026-02-15T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] Tamil Nadu: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ANDHRA PRADESH (20 records)
    // ══════════════════════════════════════════════════════════════════════════
    private void seedAndhraPradesh() {
        List<Crime> list = new ArrayList<>();

        // Visakhapatnam
        list.add(c("Cyber Crime", "Cyber crime in MVP Colony, Visakhapatnam. 9,100 cases.",        17.7384, 83.2165, "MVP Colony, Visakhapatnam, Andhra Pradesh",   "2026-01-28T10:00:00", "HIGH"));
        list.add(c("Theft",       "Theft in Gajuwaka industrial area. 8,700 cases.",               17.6868, 83.2185, "Gajuwaka, Visakhapatnam, Andhra Pradesh",    "2026-01-30T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Dwaraka Nagar, Visakhapatnam. 5,200 cases.",         17.7200, 83.3000, "Dwaraka Nagar, Visakhapatnam, Andhra Pradesh","2026-02-02T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Seethammadhara, Visakhapatnam. 3,800 cases.",        17.7300, 83.3100, "Seethammadhara, Visakhapatnam, Andhra Pradesh","2026-02-04T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Madhurawada, Visakhapatnam. 4,100 cases.",             17.7900, 83.3700, "Madhurawada, Visakhapatnam, Andhra Pradesh",  "2026-02-06T10:00:00", "MEDIUM"));

        // Vijayawada
        list.add(c("Robbery",     "Robbery near Benz Circle, Vijayawada. 7,600 cases.",            16.5062, 80.6480, "Benz Circle, Vijayawada, Andhra Pradesh",    "2026-02-02T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Governorpet, Vijayawada. 5,400 cases.",                16.5193, 80.6305, "Governorpet, Vijayawada, Andhra Pradesh",    "2026-02-05T10:00:00", "MEDIUM"));
        list.add(c("Theft",       "Theft in Patamata, Vijayawada. 6,200 cases.",                   16.5200, 80.6200, "Patamata, Vijayawada, Andhra Pradesh",       "2026-02-08T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Moghalrajpuram, Vijayawada. 3,900 cases.",       16.5100, 80.6400, "Moghalrajpuram, Vijayawada, Andhra Pradesh", "2026-02-10T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Labbipet, Vijayawada. 4,300 cases.",                 16.5000, 80.6300, "Labbipet, Vijayawada, Andhra Pradesh",       "2026-02-12T10:00:00", "MEDIUM"));

        // Tirupati
        list.add(c("Theft",       "Theft near Renigunta, Tirupati. 4,200 cases.",                  13.6288, 79.5108, "Renigunta, Tirupati, Andhra Pradesh",        "2026-02-08T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Balaji Colony, Tirupati. 3,100 cases.",              13.6500, 79.4200, "Balaji Colony, Tirupati, Andhra Pradesh",    "2026-02-10T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud near Tirumala, Tirupati. 2,600 cases.",                   13.6833, 79.3500, "Tirumala, Tirupati, Andhra Pradesh",         "2026-02-14T10:00:00", "MEDIUM"));

        // Guntur
        list.add(c("Theft",       "Theft in Brodipet, Guntur. 5,800 cases.",                       16.3067, 80.4365, "Brodipet, Guntur, Andhra Pradesh",           "2026-02-16T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Arundelpet, Guntur. 3,700 cases.",                   16.3100, 80.4400, "Arundelpet, Guntur, Andhra Pradesh",         "2026-02-18T10:00:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Cyber crime in Nagarampalem, Guntur. 2,900 cases.",             16.3200, 80.4500, "Nagarampalem, Guntur, Andhra Pradesh",       "2026-02-20T10:00:00", "MEDIUM"));

        // Kurnool
        list.add(c("Theft",       "Theft in Kurnool city centre. 4,500 cases.",                    15.8281, 78.0373, "Kurnool City, Kurnool, Andhra Pradesh",      "2026-02-22T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery in Bellary Road area, Kurnool. 2,200 cases.",           15.8300, 78.0400, "Bellary Road, Kurnool, Andhra Pradesh",      "2026-02-24T10:00:00", "HIGH"));

        // Nellore
        list.add(c("Theft",       "Theft in Pogathota, Nellore. 3,900 cases.",                     14.4426, 79.9865, "Pogathota, Nellore, Andhra Pradesh",         "2026-02-26T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Magunta Layout, Nellore. 2,100 cases.",                14.4500, 79.9900, "Magunta Layout, Nellore, Andhra Pradesh",    "2026-02-28T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] Andhra Pradesh: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — MAHARASHTRA
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBMaharashtra() {
        List<Crime> list = new ArrayList<>();

        // Mumbai Commissioner — 302 IPC crimes (Table 1-7)
        list.add(c("Theft",       "High-volume theft in Dharavi, Mumbai. NCRB Table 1-7.",         19.0400, 72.8530, "Dharavi, Mumbai, Maharashtra",               "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery incidents in Kurla, Mumbai. NCRB data.",                19.0728, 72.8826, "Kurla, Mumbai, Maharashtra",                 "2026-01-07T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault cases in Andheri, Mumbai. NCRB data.",                  19.1136, 72.8697, "Andheri, Mumbai, Maharashtra",               "2026-01-09T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Financial fraud in Bandra, Mumbai. NCRB data.",                 19.0596, 72.8295, "Bandra, Mumbai, Maharashtra",                "2026-01-11T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime surge in Mumbai. 4,724 cases. NCRB Table 1-9.",     19.0760, 72.8777, "Colaba, Mumbai, Maharashtra",                "2026-01-13T10:00:00", "HIGH"));
        list.add(c("Burglary",    "Burglary in Borivali, Mumbai. NCRB data.",                      19.2307, 72.8567, "Borivali, Mumbai, Maharashtra",              "2026-01-15T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder cases in Govandi, Mumbai. NCRB data.",                   19.0500, 72.9200, "Govandi, Mumbai, Maharashtra",               "2026-01-17T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping cases in Malad, Mumbai. NCRB data.",                 19.1874, 72.8484, "Malad, Mumbai, Maharashtra",                 "2026-01-19T10:00:00", "HIGH"));

        // Pune Commissioner — 248 IPC crimes
        list.add(c("Theft",       "Theft in Shivajinagar, Pune. NCRB data.",                       18.5314, 73.8446, "Shivajinagar, Pune, Maharashtra",            "2026-01-06T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Kothrud, Pune. NCRB data.",                      18.5074, 73.8077, "Kothrud, Pune, Maharashtra",                 "2026-01-08T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Hadapsar, Pune. NCRB data.",                         18.5018, 73.9260, "Hadapsar, Pune, Maharashtra",                "2026-01-10T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Viman Nagar, Pune. NCRB data.",                        18.5679, 73.9143, "Viman Nagar, Pune, Maharashtra",             "2026-01-12T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery in Pimpri, Pune. NCRB data.",                           18.6298, 73.7997, "Pimpri, Pune, Maharashtra",                  "2026-01-14T10:00:00", "HIGH"));

        // Thane Commissioner — 254 IPC crimes
        list.add(c("Theft",       "Theft in Thane city. NCRB data.",                               19.2183, 72.9781, "Thane City, Thane, Maharashtra",             "2026-01-16T10:00:00", "HIGH"));
        list.add(c("Burglary",    "Burglary in Kalyan, Thane. NCRB data.",                         19.2437, 73.1355, "Kalyan, Thane, Maharashtra",                 "2026-01-18T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Dombivli, Thane. NCRB data.",                        19.2183, 73.0894, "Dombivli, Thane, Maharashtra",               "2026-01-20T10:00:00", "MEDIUM"));

        // Nagpur Commissioner — 206 IPC crimes
        list.add(c("Theft",       "Theft in Sitabuldi, Nagpur. NCRB data.",                        21.1458, 79.0882, "Sitabuldi, Nagpur, Maharashtra",             "2026-01-22T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Dharampeth, Nagpur. NCRB data.",                       21.1500, 79.0700, "Dharampeth, Nagpur, Maharashtra",            "2026-01-24T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Gandhibagh, Nagpur. NCRB data.",                     21.1400, 79.0900, "Gandhibagh, Nagpur, Maharashtra",            "2026-01-26T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Maharashtra: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — UTTAR PRADESH
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBUttarPradesh() {
        List<Crime> list = new ArrayList<>();

        // Lucknow — 2186 IPC crimes (highest in Table 1-7)
        list.add(c("Theft",       "High-volume theft in Hazratganj, Lucknow. 2,186 IPC cases.",    26.8467, 80.9462, "Hazratganj, Lucknow, Uttar Pradesh",         "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Gomti Nagar, Lucknow. NCRB data.",                   26.8600, 81.0000, "Gomti Nagar, Lucknow, Uttar Pradesh",        "2026-01-07T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Lucknow. 1,134 cases. NCRB Table 1-9.",          26.8467, 80.9462, "Aliganj, Lucknow, Uttar Pradesh",            "2026-01-09T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery in Chowk area, Lucknow. NCRB data.",                    26.8600, 80.9200, "Chowk, Lucknow, Uttar Pradesh",              "2026-01-11T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Indira Nagar, Lucknow. NCRB data.",                    26.8800, 81.0100, "Indira Nagar, Lucknow, Uttar Pradesh",       "2026-01-13T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder cases in Alambagh, Lucknow. NCRB data.",                 26.8200, 80.9100, "Alambagh, Lucknow, Uttar Pradesh",           "2026-01-15T10:00:00", "HIGH"));

        // Ghaziabad — 810 IPC crimes
        list.add(c("Theft",       "Theft in Vaishali, Ghaziabad. 810 IPC cases. NCRB data.",       28.6450, 77.3200, "Vaishali, Ghaziabad, Uttar Pradesh",         "2026-01-06T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Indirapuram, Ghaziabad. NCRB data.",                 28.6400, 77.3700, "Indirapuram, Ghaziabad, Uttar Pradesh",      "2026-01-08T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Raj Nagar, Ghaziabad. NCRB data.",                   28.6700, 77.4200, "Raj Nagar, Ghaziabad, Uttar Pradesh",        "2026-01-10T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Kaushambi, Ghaziabad. NCRB data.",               28.6300, 77.3400, "Kaushambi, Ghaziabad, Uttar Pradesh",        "2026-01-12T10:00:00", "MEDIUM"));

        // Kanpur — 541 IPC crimes
        list.add(c("Theft",       "Theft in Swaroop Nagar, Kanpur. 541 IPC cases. NCRB data.",     26.4499, 80.3319, "Swaroop Nagar, Kanpur, Uttar Pradesh",       "2026-01-14T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Kanpur. 541 cases. NCRB Table 1-9.",             26.4499, 80.3319, "Kakadeo, Kanpur, Uttar Pradesh",             "2026-01-16T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Kidwai Nagar, Kanpur. NCRB data.",                     26.4600, 80.3400, "Kidwai Nagar, Kanpur, Uttar Pradesh",        "2026-01-18T10:00:00", "MEDIUM"));

        // Prayagraj — 93 IPC crimes
        list.add(c("Theft",       "Theft in Civil Lines, Prayagraj. NCRB data.",                   25.4358, 81.8463, "Civil Lines, Prayagraj, Uttar Pradesh",      "2026-01-20T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Naini, Prayagraj. NCRB data.",                       25.4000, 81.8700, "Naini, Prayagraj, Uttar Pradesh",            "2026-01-22T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Uttar Pradesh: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — RAJASTHAN
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBRajasthan() {
        List<Crime> list = new ArrayList<>();

        // Jaipur
        list.add(c("Theft",       "Theft in Jaipur city. NCRB Table 1-7 data.",                   26.9124, 75.7873, "Jaipur East, Jaipur, Rajasthan",             "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Mansarovar, Jaipur. NCRB data.",                    26.8600, 75.7700, "Mansarovar, Jaipur, Rajasthan",              "2026-01-07T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Vaishali Nagar, Jaipur. NCRB data.",                26.9200, 75.7400, "Vaishali Nagar, Jaipur, Rajasthan",          "2026-01-09T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Malviya Nagar, Jaipur. NCRB data.",                   26.8500, 75.8000, "Malviya Nagar, Jaipur, Rajasthan",           "2026-01-11T10:00:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Cyber crime in Jaipur. NCRB data.",                            26.9124, 75.7873, "Tonk Road, Jaipur, Rajasthan",               "2026-01-13T10:00:00", "MEDIUM"));

        // Udaipur — 292 IPC crimes
        list.add(c("Theft",       "Theft in Udaipur city. 292 IPC cases. NCRB data.",             24.5854, 73.7125, "Udaipur City, Udaipur, Rajasthan",           "2026-01-15T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Hiran Magri, Udaipur. NCRB data.",                  24.5900, 73.7200, "Hiran Magri, Udaipur, Rajasthan",            "2026-01-17T10:00:00", "MEDIUM"));
        list.add(c("Burglary",    "Burglary in Pratap Nagar, Udaipur. NCRB data.",                24.5700, 73.7000, "Pratap Nagar, Udaipur, Rajasthan",           "2026-01-19T10:00:00", "MEDIUM"));

        // Jodhpur — 114 IPC crimes
        list.add(c("Theft",       "Theft in Jodhpur East. 114 IPC cases. NCRB data.",             26.2389, 73.0243, "Jodhpur East, Jodhpur, Rajasthan",           "2026-01-21T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery in Sardarpura, Jodhpur. NCRB data.",                   26.2500, 73.0100, "Sardarpura, Jodhpur, Rajasthan",             "2026-01-23T10:00:00", "HIGH"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Rajasthan: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — DELHI
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBDelhi() {
        List<Crime> list = new ArrayList<>();

        // North-West Delhi — 220 IPC crimes
        list.add(c("Theft",       "Theft in Rohini, Delhi. 220 IPC cases. NCRB data.",            28.7041, 77.1025, "Rohini, North-West Delhi",                   "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Pitampura, Delhi. NCRB data.",                      28.7000, 77.1300, "Pitampura, North-West Delhi",                "2026-01-07T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Shalimar Bagh, Delhi. NCRB data.",                  28.7200, 77.1600, "Shalimar Bagh, North-West Delhi",            "2026-01-09T10:00:00", "HIGH"));

        // Outer North Delhi — 198 IPC crimes
        list.add(c("Theft",       "Theft in Bawana, Outer North Delhi. NCRB data.",               28.7900, 77.0400, "Bawana, Outer North Delhi",                  "2026-01-11T10:00:00", "HIGH"));
        list.add(c("Burglary",    "Burglary in Narela, Delhi. NCRB data.",                        28.8500, 77.0900, "Narela, Outer North Delhi",                  "2026-01-13T10:00:00", "MEDIUM"));

        // West Delhi — 156 IPC crimes
        list.add(c("Theft",       "Theft in Janakpuri, West Delhi. NCRB data.",                   28.6219, 77.0878, "Janakpuri, West Delhi",                      "2026-01-15T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Tilak Nagar, West Delhi. NCRB data.",                 28.6400, 77.1000, "Tilak Nagar, West Delhi",                    "2026-01-17T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Uttam Nagar, West Delhi. NCRB data.",               28.6200, 77.0600, "Uttam Nagar, West Delhi",                    "2026-01-19T10:00:00", "MEDIUM"));

        // Rohini — 142 IPC crimes
        list.add(c("Cyber Crime", "Cyber crime in Rohini district, Delhi. NCRB data.",            28.7041, 77.1025, "Rohini Sector 3, Delhi",                     "2026-01-21T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Rohini Sector 7, Delhi. NCRB data.",                28.7100, 77.1100, "Rohini Sector 7, Delhi",                     "2026-01-23T10:00:00", "HIGH"));

        // South Delhi
        list.add(c("Fraud",       "Fraud in Saket, South Delhi. NCRB data.",                      28.5244, 77.2066, "Saket, South Delhi",                         "2026-01-25T10:00:00", "HIGH"));
        list.add(c("Theft",       "Theft in Lajpat Nagar, South Delhi. NCRB data.",               28.5700, 77.2400, "Lajpat Nagar, South Delhi",                  "2026-01-27T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Delhi: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — MADHYA PRADESH
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBMadhyaPradesh() {
        List<Crime> list = new ArrayList<>();

        // Bhopal — 296 IPC crimes
        list.add(c("Theft",       "Theft in MP Nagar, Bhopal. 296 IPC cases. NCRB data.",         23.2599, 77.4126, "MP Nagar, Bhopal, Madhya Pradesh",           "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Kolar Road, Bhopal. NCRB data.",                    23.2200, 77.4500, "Kolar Road, Bhopal, Madhya Pradesh",         "2026-01-07T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Habibganj, Bhopal. NCRB data.",                     23.2300, 77.4300, "Habibganj, Bhopal, Madhya Pradesh",          "2026-01-09T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Arera Colony, Bhopal. NCRB data.",                    23.2100, 77.4200, "Arera Colony, Bhopal, Madhya Pradesh",       "2026-01-11T10:00:00", "MEDIUM"));

        // Indore — 204 IPC crimes
        list.add(c("Theft",       "Theft in Vijay Nagar, Indore. 204 IPC cases. NCRB data.",      22.7196, 75.8577, "Vijay Nagar, Indore, Madhya Pradesh",        "2026-01-13T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Palasia, Indore. NCRB data.",                   22.7300, 75.8700, "Palasia, Indore, Madhya Pradesh",            "2026-01-15T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Rajwada area, Indore. NCRB data.",                  22.7200, 75.8600, "Rajwada, Indore, Madhya Pradesh",            "2026-01-17T10:00:00", "MEDIUM"));

        // Gwalior — 94 IPC crimes
        list.add(c("Theft",       "Theft in Lashkar, Gwalior. 94 IPC cases. NCRB data.",          26.2183, 78.1828, "Lashkar, Gwalior, Madhya Pradesh",           "2026-01-19T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Morar, Gwalior. NCRB data.",                        26.2300, 78.2000, "Morar, Gwalior, Madhya Pradesh",             "2026-01-21T10:00:00", "HIGH"));

        // Jabalpur — 85 IPC crimes
        list.add(c("Theft",       "Theft in Napier Town, Jabalpur. 85 IPC cases. NCRB data.",     23.1815, 79.9864, "Napier Town, Jabalpur, Madhya Pradesh",      "2026-01-23T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Gorakhpur, Jabalpur. NCRB data.",                   23.1700, 79.9700, "Gorakhpur, Jabalpur, Madhya Pradesh",        "2026-01-25T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Madhya Pradesh: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — GUJARAT
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBGujarat() {
        List<Crime> list = new ArrayList<>();

        // Ahmedabad City — 377 IPC crimes
        list.add(c("Theft",       "Theft in Maninagar, Ahmedabad. 377 IPC cases. NCRB data.",     23.0225, 72.5714, "Maninagar, Ahmedabad, Gujarat",              "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Navrangpura, Ahmedabad. NCRB data.",                  23.0400, 72.5600, "Navrangpura, Ahmedabad, Gujarat",            "2026-01-07T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Bapunagar, Ahmedabad. NCRB data.",                  23.0600, 72.6200, "Bapunagar, Ahmedabad, Gujarat",              "2026-01-09T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Vatva, Ahmedabad. NCRB data.",                      22.9800, 72.6400, "Vatva, Ahmedabad, Gujarat",                  "2026-01-11T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Satellite, Ahmedabad. NCRB data.",              23.0300, 72.5200, "Satellite, Ahmedabad, Gujarat",              "2026-01-13T10:00:00", "MEDIUM"));

        // Surat City — 136 IPC crimes
        list.add(c("Theft",       "Theft in Adajan, Surat. 136 IPC cases. NCRB data.",            21.1702, 72.8311, "Adajan, Surat, Gujarat",                     "2026-01-15T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Katargam, Surat. NCRB data.",                       21.2200, 72.8500, "Katargam, Surat, Gujarat",                   "2026-01-17T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Varachha, Surat. NCRB data.",                         21.2100, 72.8700, "Varachha, Surat, Gujarat",                   "2026-01-19T10:00:00", "MEDIUM"));

        // Vadodara City — 78 IPC crimes
        list.add(c("Theft",       "Theft in Alkapuri, Vadodara. 78 IPC cases. NCRB data.",        22.3072, 73.1812, "Alkapuri, Vadodara, Gujarat",                "2026-01-21T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Fatehgunj, Vadodara. NCRB data.",                   22.3200, 73.1900, "Fatehgunj, Vadodara, Gujarat",               "2026-01-23T10:00:00", "HIGH"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Gujarat: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — WEST BENGAL
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBWestBengal() {
        List<Crime> list = new ArrayList<>();

        // Murshidabad — 134 IPC crimes
        list.add(c("Theft",       "Theft in Berhampore, Murshidabad. 134 IPC cases. NCRB data.",  24.1060, 88.2500, "Berhampore, Murshidabad, West Bengal",        "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Jangipur, Murshidabad. NCRB data.",                 24.4700, 88.0700, "Jangipur, Murshidabad, West Bengal",          "2026-01-07T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Lalbagh, Murshidabad. NCRB data.",                  24.1800, 88.2700, "Lalbagh, Murshidabad, West Bengal",           "2026-01-09T10:00:00", "HIGH"));

        // Kolkata — 75 IPC crimes
        list.add(c("Theft",       "Theft in Park Street, Kolkata. 75 IPC cases. NCRB data.",      22.5726, 88.3639, "Park Street, Kolkata, West Bengal",           "2026-01-11T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Salt Lake, Kolkata. NCRB data.",                      22.5800, 88.4200, "Salt Lake, Kolkata, West Bengal",             "2026-01-13T10:00:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Cyber crime in Kolkata. NCRB data.",                           22.5726, 88.3639, "Esplanade, Kolkata, West Bengal",             "2026-01-15T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Howrah, Kolkata. NCRB data.",                       22.5958, 88.2636, "Howrah, Kolkata, West Bengal",                "2026-01-17T10:00:00", "MEDIUM"));

        // Barrackpur Police Commissionerate — 37 IPC crimes
        list.add(c("Theft",       "Theft in Barrackpur, West Bengal. NCRB data.",                 22.7600, 88.3700, "Barrackpur, North 24 Parganas, West Bengal",  "2026-01-19T10:00:00", "MEDIUM"));
        list.add(c("Burglary",    "Burglary in Titagarh, West Bengal. NCRB data.",                22.7400, 88.3700, "Titagarh, North 24 Parganas, West Bengal",    "2026-01-21T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB West Bengal: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — TELANGANA
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBTelangana() {
        List<Crime> list = new ArrayList<>();

        // Hyderabad — 265 IPC + 4436 cyber crimes
        list.add(c("Theft",       "Theft in Abids, Hyderabad. 265 IPC cases. NCRB data.",         17.3850, 78.4867, "Abids, Hyderabad, Telangana",                "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Cyber Crime", "Cyber crime in Hyderabad. 4,436 cases. NCRB Table 1-9.",       17.3850, 78.4867, "Banjara Hills, Hyderabad, Telangana",         "2026-01-07T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Secunderabad, Hyderabad. NCRB data.",               17.4399, 78.4983, "Secunderabad, Hyderabad, Telangana",          "2026-01-09T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Charminar area, Hyderabad. NCRB data.",             17.3616, 78.4747, "Charminar, Hyderabad, Telangana",             "2026-01-11T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Jubilee Hills, Hyderabad. NCRB data.",                17.4300, 78.4100, "Jubilee Hills, Hyderabad, Telangana",         "2026-01-13T10:00:00", "HIGH"));

        // Cyberabad — 86 IPC + 5424 cyber crimes (highest cyber in Telangana)
        list.add(c("Cyber Crime", "Cyber crime in Cyberabad. 5,424 cases. NCRB Table 1-9.",       17.4500, 78.3800, "Madhapur, Cyberabad, Telangana",              "2026-01-15T10:00:00", "HIGH"));
        list.add(c("Theft",       "Theft in Kondapur, Cyberabad. NCRB data.",                     17.4600, 78.3600, "Kondapur, Cyberabad, Telangana",              "2026-01-17T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud in Gachibowli, Cyberabad. NCRB data.",                   17.4400, 78.3500, "Gachibowli, Cyberabad, Telangana",            "2026-01-19T10:00:00", "HIGH"));

        // Rachakonda — 58 IPC + 2192 cyber crimes
        list.add(c("Cyber Crime", "Cyber crime in Rachakonda. 2,192 cases. NCRB Table 1-9.",      17.3700, 78.5500, "LB Nagar, Rachakonda, Telangana",             "2026-01-21T10:00:00", "HIGH"));
        list.add(c("Theft",       "Theft in Uppal, Rachakonda. NCRB data.",                       17.4000, 78.5600, "Uppal, Rachakonda, Telangana",                "2026-01-23T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Telangana: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — KERALA
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBKerala() {
        List<Crime> list = new ArrayList<>();

        // Trivandrum Rural — 38 IPC crimes
        list.add(c("Theft",       "Theft in Trivandrum Rural. 38 IPC cases. NCRB data.",          8.5241,  76.9366, "Trivandrum Rural, Thiruvananthapuram, Kerala","2026-01-05T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Neyyattinkara, Trivandrum. NCRB data.",             8.4000,  77.0900, "Neyyattinkara, Thiruvananthapuram, Kerala",   "2026-01-07T10:00:00", "MEDIUM"));

        // Malappuram — 52 IPC crimes
        list.add(c("Theft",       "Theft in Malappuram town. 52 IPC cases. NCRB data.",           11.0510, 76.0711, "Malappuram Town, Malappuram, Kerala",         "2026-01-09T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Tirur, Malappuram. NCRB data.",                       10.9100, 75.9200, "Tirur, Malappuram, Kerala",                   "2026-01-11T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Manjeri, Malappuram. NCRB data.",                   11.1200, 76.1200, "Manjeri, Malappuram, Kerala",                 "2026-01-13T10:00:00", "MEDIUM"));

        // Ernakulam Commissioner — 21 IPC crimes
        list.add(c("Theft",       "Theft in MG Road, Ernakulam. 21 IPC cases. NCRB data.",        9.9312,  76.2673, "MG Road, Ernakulam, Kerala",                  "2026-01-15T10:00:00", "MEDIUM"));
        list.add(c("Cyber Crime", "Cyber crime in Kakkanad, Ernakulam. NCRB data.",               10.0200, 76.3400, "Kakkanad, Ernakulam, Kerala",                 "2026-01-17T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Aluva, Ernakulam. NCRB data.",                        10.1000, 76.3500, "Aluva, Ernakulam, Kerala",                    "2026-01-19T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Kerala: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — PUNJAB
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBPunjab() {
        List<Crime> list = new ArrayList<>();

        // Ludhiana — 53 IPC crimes
        list.add(c("Theft",       "Theft in Ludhiana city. 53 IPC cases. NCRB data.",             30.9010, 75.8573, "Ludhiana City, Ludhiana, Punjab",             "2026-01-05T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Sarabha Nagar, Ludhiana. NCRB data.",               30.9100, 75.8700, "Sarabha Nagar, Ludhiana, Punjab",             "2026-01-07T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Focal Point, Ludhiana. NCRB data.",                 30.8800, 75.8400, "Focal Point, Ludhiana, Punjab",               "2026-01-09T10:00:00", "HIGH"));

        // Jalandhar — 44 IPC crimes
        list.add(c("Theft",       "Theft in Jalandhar city. 44 IPC cases. NCRB data.",            31.3260, 75.5762, "Jalandhar City, Jalandhar, Punjab",           "2026-01-11T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Model Town, Jalandhar. NCRB data.",                   31.3400, 75.5900, "Model Town, Jalandhar, Punjab",               "2026-01-13T10:00:00", "MEDIUM"));

        // Patiala — 42 IPC crimes
        list.add(c("Theft",       "Theft in Patiala city. 42 IPC cases. NCRB data.",              30.3398, 76.3869, "Patiala City, Patiala, Punjab",               "2026-01-15T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault in Rajpura, Patiala. NCRB data.",                      30.4800, 76.5900, "Rajpura, Patiala, Punjab",                    "2026-01-17T10:00:00", "MEDIUM"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Punjab: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // NCRB DATA — HARYANA
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBHaryana() {
        List<Crime> list = new ArrayList<>();

        // Sonipat — 131 IPC crimes
        list.add(c("Theft",       "Theft in Sonipat city. 131 IPC cases. NCRB data.",             28.9931, 77.0151, "Sonipat City, Sonipat, Haryana",              "2026-01-05T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in Gohana, Sonipat. NCRB data.",                       29.1400, 76.7000, "Gohana, Sonipat, Haryana",                    "2026-01-07T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery in Kundli, Sonipat. NCRB data.",                       28.8700, 77.0600, "Kundli, Sonipat, Haryana",                    "2026-01-09T10:00:00", "HIGH"));

        // Faridabad — 127 IPC crimes
        list.add(c("Theft",       "Theft in Faridabad city. 127 IPC cases. NCRB data.",           28.4089, 77.3178, "Faridabad City, Faridabad, Haryana",          "2026-01-11T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault in NIT Faridabad. NCRB data.",                         28.3900, 77.3100, "NIT, Faridabad, Haryana",                     "2026-01-13T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Ballabhgarh, Faridabad. NCRB data.",                  28.3400, 77.3200, "Ballabhgarh, Faridabad, Haryana",             "2026-01-15T10:00:00", "MEDIUM"));

        // Gurugram — 79 IPC crimes
        list.add(c("Cyber Crime", "Cyber crime in Gurugram. NCRB data.",                          28.4595, 77.0266, "DLF Phase 1, Gurugram, Haryana",              "2026-01-17T10:00:00", "HIGH"));
        list.add(c("Theft",       "Theft in Sohna Road, Gurugram. NCRB data.",                    28.4200, 77.0400, "Sohna Road, Gurugram, Haryana",               "2026-01-19T10:00:00", "MEDIUM"));
        list.add(c("Fraud",       "Fraud in Sector 14, Gurugram. NCRB data.",                     28.4700, 77.0300, "Sector 14, Gurugram, Haryana",                "2026-01-21T10:00:00", "HIGH"));

        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Haryana: inserted " + list.size() + " records.");
    }
    // ══════════════════════════════════════════════════════════════════════════
    // NCRB TABLE 1-10 — KARNATAKA VICTIM DATA
    // ══════════════════════════════════════════════════════════════════════════
    private void seedNCRBVictimDataKarnataka() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Shivajinagar, Bengaluru. NCRB Table 1-10.",   12.9800, 77.5900, "Shivajinagar, Bengaluru City, Karnataka",     "2026-03-01T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Rajajinagar, Bengaluru. NCRB Table 1-10.",   12.9900, 77.5500, "Rajajinagar, Bengaluru City, Karnataka",      "2026-03-03T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Jayanagar, Bengaluru. NCRB Table 1-10.",  12.9250, 77.5938, "Jayanagar, Bengaluru City, Karnataka",        "2026-03-05T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Malleswaram, Bengaluru. NCRB Table 1-10.",   13.0035, 77.5680, "Malleswaram, Bengaluru City, Karnataka",      "2026-03-07T10:00:00", "HIGH"));
        list.add(c("Fraud",       "Fraud victims in Electronic City, Bengaluru. NCRB Table 1-10.", 12.8458, 77.6603, "Electronic City, Bengaluru City, Karnataka",  "2026-03-09T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Lakshmipuram, Mysuru. NCRB Table 1-10.",     12.3100, 76.6500, "Lakshmipuram, Mysuru City, Karnataka",        "2026-03-11T10:00:00", "MEDIUM"));
        list.add(c("Theft",       "Theft victims in Nazarbad, Mysuru. NCRB Table 1-10.",           12.3000, 76.6400, "Nazarbad, Mysuru City, Karnataka",            "2026-03-13T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Mandya town. 753 total victims. NCRB 1-10.", 12.5218, 76.8951, "Mandya Town, Mandya, Karnataka",              "2026-03-15T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery victims in Maddur, Mandya. NCRB Table 1-10.",           12.5800, 77.0400, "Maddur, Mandya, Karnataka",                   "2026-03-17T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Shimoga city. 871 total victims. NCRB 1-10.",14.1995, 75.5679, "Shimoga City, Shimoga, Karnataka",            "2026-03-19T10:00:00", "MEDIUM"));
        list.add(c("Theft",       "Theft victims in Bhadravathi, Shimoga. NCRB Table 1-10.",       13.8500, 75.7000, "Bhadravathi, Shimoga, Karnataka",             "2026-03-21T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Davanagere city. 716 total victims.",        14.4644, 75.9218, "Davanagere City, Davanagere, Karnataka",      "2026-03-23T10:00:00", "MEDIUM"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim Karnataka: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataTelangana() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Hayathnagar, Rachakonda. NCRB Table 1-10.",   17.3300, 78.6000, "Hayathnagar, Rachakonda, Telangana",          "2026-03-02T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Vanasthalipuram, Rachakonda. NCRB 1-10.",    17.3400, 78.5700, "Vanasthalipuram, Rachakonda, Telangana",      "2026-03-04T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Saroornagar, Rachakonda. NCRB 1-10.",     17.3500, 78.5400, "Saroornagar, Rachakonda, Telangana",          "2026-03-06T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Boduppal, Rachakonda. NCRB Table 1-10.",     17.4200, 78.5800, "Boduppal, Rachakonda, Telangana",             "2026-03-08T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Balanagar, Cyberabad. NCRB Table 1-10.",      17.4800, 78.4200, "Balanagar, Cyberabad, Telangana",             "2026-03-10T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Miyapur, Cyberabad. NCRB Table 1-10.",       17.4900, 78.3600, "Miyapur, Cyberabad, Telangana",               "2026-03-12T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Kukatpally, Cyberabad. NCRB 1-10.",       17.4849, 78.4138, "Kukatpally, Cyberabad, Telangana",            "2026-03-14T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Nampally, Hyderabad. NCRB Table 1-10.",       17.3800, 78.4700, "Nampally, Hyderabad, Telangana",              "2026-03-16T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Musheerabad, Hyderabad. NCRB 1-10.",         17.4000, 78.4900, "Musheerabad, Hyderabad, Telangana",           "2026-03-18T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Malakpet, Hyderabad. NCRB Table 1-10.",      17.3700, 78.5000, "Malakpet, Hyderabad, Telangana",              "2026-03-20T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Hanamkonda, Warangal. NCRB Table 1-10.",     18.0000, 79.5700, "Hanamkonda, Warangal, Telangana",             "2026-03-22T10:00:00", "MEDIUM"));
        list.add(c("Theft",       "Theft victims in Kazipet, Warangal. NCRB Table 1-10.",          17.9700, 79.5200, "Kazipet, Warangal, Telangana",                "2026-03-24T10:00:00", "MEDIUM"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim Telangana: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataTamilNadu() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Vyasarpadi, Chennai. NCRB Table 1-10.",       13.1000, 80.2600, "Vyasarpadi, Chennai, Tamil Nadu",             "2026-03-01T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Kodambakkam, Chennai. NCRB Table 1-10.",     13.0500, 80.2200, "Kodambakkam, Chennai, Tamil Nadu",            "2026-03-03T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Ambattur, Chennai. NCRB Table 1-10.",     13.1100, 80.1500, "Ambattur, Chennai, Tamil Nadu",               "2026-03-05T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Royapuram, Chennai. NCRB Table 1-10.",       13.1200, 80.2900, "Royapuram, Chennai, Tamil Nadu",              "2026-03-07T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Avadi, Chennai. 1,533 total victims.",       13.1143, 80.0980, "Avadi, Chennai, Tamil Nadu",                  "2026-03-09T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Poonamallee, Avadi. NCRB Table 1-10.",        13.0500, 80.1000, "Poonamallee, Avadi, Tamil Nadu",              "2026-03-11T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Thiruvallur, Avadi. NCRB Table 1-10.",    13.1400, 79.9100, "Thiruvallur, Avadi, Tamil Nadu",              "2026-03-13T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Tambaram. 725 total victims. NCRB 1-10.",    12.9249, 80.1000, "Tambaram, Chennai, Tamil Nadu",               "2026-03-15T10:00:00", "MEDIUM"));
        list.add(c("Robbery",     "Robbery victims in Pallavaram, Tambaram. NCRB Table 1-10.",     12.9700, 80.1500, "Pallavaram, Tambaram, Tamil Nadu",            "2026-03-17T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Coimbatore City. 880 total victims.",        11.0168, 76.9558, "Coimbatore City, Coimbatore, Tamil Nadu",     "2026-03-19T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Singanallur, Coimbatore. NCRB 1-10.",         11.0000, 77.0200, "Singanallur, Coimbatore, Tamil Nadu",         "2026-03-21T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Madurai City. 889 total victims. NCRB 1-10.",9.9252, 78.1198, "Madurai City, Madurai, Tamil Nadu",           "2026-03-23T10:00:00", "MEDIUM"));
        list.add(c("Kidnapping",  "Kidnapping victims in Avaniyapuram, Madurai. NCRB 1-10.",       9.9000, 78.1100, "Avaniyapuram, Madurai, Tamil Nadu",           "2026-03-25T10:00:00", "MEDIUM"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim Tamil Nadu: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataWestBengal() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Entally, Kolkata. NCRB Table 1-10.",          22.5600, 88.3800, "Entally, Kolkata, West Bengal",               "2026-03-02T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Tiljala, Kolkata. NCRB Table 1-10.",         22.5300, 88.3900, "Tiljala, Kolkata, West Bengal",               "2026-03-04T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Shyambazar, Kolkata. NCRB 1-10.",         22.5900, 88.3700, "Shyambazar, Kolkata, West Bengal",            "2026-03-06T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Behala, Kolkata. NCRB Table 1-10.",          22.5000, 88.3100, "Behala, Kolkata, West Bengal",                "2026-03-08T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Barrackpur. 3,086 total victims. NCRB 1-10.", 22.7600, 88.3700, "Barrackpur, North 24 Parganas, West Bengal",  "2026-03-10T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Shyamnagar, Barrackpur. NCRB 1-10.",         22.8000, 88.3800, "Shyamnagar, Barrackpur, West Bengal",         "2026-03-12T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Naihati, Barrackpur. NCRB 1-10.",         22.8900, 88.4200, "Naihati, Barrackpur, West Bengal",            "2026-03-14T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Shibpur, Howrah. NCRB Table 1-10.",           22.5800, 88.3100, "Shibpur, Howrah, West Bengal",                "2026-03-16T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Liluah, Howrah. NCRB Table 1-10.",           22.6100, 88.3300, "Liluah, Howrah, West Bengal",                 "2026-03-18T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Domkal, Murshidabad. NCRB Table 1-10.",       24.1400, 88.5500, "Domkal, Murshidabad, West Bengal",            "2026-03-20T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Raninagar, Murshidabad. NCRB 1-10.",         24.2000, 88.3500, "Raninagar, Murshidabad, West Bengal",         "2026-03-22T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Coochbehar town. 2,339 total victims.",      26.3452, 89.4457, "Coochbehar Town, Coochbehar, West Bengal",    "2026-03-24T10:00:00", "MEDIUM"));
        list.add(c("Kidnapping",  "Kidnapping victims in Dinhata, Coochbehar. NCRB 1-10.",         26.1300, 89.4700, "Dinhata, Coochbehar, West Bengal",            "2026-03-26T10:00:00", "MEDIUM"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim West Bengal: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataRajasthan() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Udaipur city. 2,098 total victims. NCRB 1-10.",24.5854, 73.7125, "Udaipur City, Udaipur, Rajasthan",           "2026-03-02T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Fatehpura, Udaipur. NCRB Table 1-10.",       24.5700, 73.7300, "Fatehpura, Udaipur, Rajasthan",               "2026-03-04T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Mavli, Udaipur. NCRB Table 1-10.",        24.7500, 73.9000, "Mavli, Udaipur, Rajasthan",                   "2026-03-06T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Jaipur West. 1,203 total victims. NCRB 1-10.",26.9124, 75.7873, "Jaipur West, Jaipur, Rajasthan",              "2026-03-08T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Sanganer, Jaipur West. NCRB 1-10.",          26.8200, 75.8200, "Sanganer, Jaipur West, Rajasthan",            "2026-03-10T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Kota City. 1,158 total victims. NCRB 1-10.",  25.2138, 75.8648, "Kota City, Kota, Rajasthan",                  "2026-03-12T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Vigyan Nagar, Kota. NCRB Table 1-10.",       25.2200, 75.8700, "Vigyan Nagar, Kota, Rajasthan",               "2026-03-14T10:00:00", "MEDIUM"));
        list.add(c("Kidnapping",  "Kidnapping victims in Dadabari, Kota. NCRB Table 1-10.",        25.2000, 75.8500, "Dadabari, Kota, Rajasthan",                   "2026-03-16T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Ajmer city. 1,860 total victims. NCRB 1-10.", 26.4499, 74.6399, "Ajmer City, Ajmer, Rajasthan",                "2026-03-18T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Pushkar, Ajmer. NCRB Table 1-10.",           26.4900, 74.5500, "Pushkar, Ajmer, Rajasthan",                   "2026-03-20T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Bhilwara city. 1,748 total victims.",        25.3500, 74.6300, "Bhilwara City, Bhilwara, Rajasthan",          "2026-03-22T10:00:00", "MEDIUM"));
        list.add(c("Kidnapping",  "Kidnapping victims in Shahpura, Bhilwara. NCRB 1-10.",          25.6200, 74.9200, "Shahpura, Bhilwara, Rajasthan",               "2026-03-24T10:00:00", "MEDIUM"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim Rajasthan: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataMadhyaPradesh2() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Indore city. 4,017 total victims. NCRB 1-10.",22.7196, 75.8577, "Indore City, Indore, Madhya Pradesh",         "2026-03-01T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Annapurna, Indore. NCRB Table 1-10.",        22.6900, 75.8700, "Annapurna, Indore, Madhya Pradesh",           "2026-03-03T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Lasudia, Indore. NCRB Table 1-10.",       22.7500, 75.9200, "Lasudia, Indore, Madhya Pradesh",             "2026-03-05T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Banganga, Indore. NCRB Table 1-10.",         22.7100, 75.8400, "Banganga, Indore, Madhya Pradesh",            "2026-03-07T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Jabalpur city. 3,062 total victims. NCRB 1-10.",23.1815, 79.9864, "Jabalpur City, Jabalpur, Madhya Pradesh",  "2026-03-09T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Adhartal, Jabalpur. NCRB Table 1-10.",       23.1700, 79.9700, "Adhartal, Jabalpur, Madhya Pradesh",          "2026-03-11T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Vijay Nagar, Jabalpur. NCRB 1-10.",       23.2000, 79.9900, "Vijay Nagar, Jabalpur, Madhya Pradesh",       "2026-03-13T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Gwalior city. 2,041 total victims. NCRB 1-10.",26.2183, 78.1828, "Gwalior City, Gwalior, Madhya Pradesh",     "2026-03-15T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Thatipur, Gwalior. NCRB Table 1-10.",        26.2300, 78.2100, "Thatipur, Gwalior, Madhya Pradesh",           "2026-03-17T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Sagar city. 2,450 total victims. NCRB 1-10.", 23.8388, 78.7378, "Sagar City, Sagar, Madhya Pradesh",           "2026-03-19T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Makronia, Sagar. NCRB Table 1-10.",          23.8500, 78.7500, "Makronia, Sagar, Madhya Pradesh",             "2026-03-21T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Raipur city. 2,702 total victims. NCRB 1-10.",21.2514, 81.6296, "Raipur City, Raipur, Chhattisgarh",          "2026-03-23T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Telibandha, Raipur. NCRB Table 1-10.",       21.2400, 81.6400, "Telibandha, Raipur, Chhattisgarh",            "2026-03-25T10:00:00", "HIGH"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim MP/CG: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataUttarPradesh2() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Noida, Gautambudh Nagar. NCRB Table 1-10.",   28.5355, 77.3910, "Noida, Gautambudh Nagar, Uttar Pradesh",      "2026-03-02T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Greater Noida. NCRB Table 1-10.",            28.4744, 77.5040, "Greater Noida, Gautambudh Nagar, Uttar Pradesh","2026-03-04T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Dadri, Gautambudh Nagar. NCRB 1-10.",     28.5500, 77.5500, "Dadri, Gautambudh Nagar, Uttar Pradesh",      "2026-03-06T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Kanpur city. 770 total victims. NCRB 1-10.",  26.4499, 80.3319, "Kanpur City, Kanpur, Uttar Pradesh",           "2026-03-08T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Armapur, Kanpur. NCRB Table 1-10.",          26.4700, 80.3100, "Armapur, Kanpur, Uttar Pradesh",              "2026-03-10T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Varanasi city. 463 total victims. NCRB 1-10.",25.3176, 82.9739, "Varanasi City, Varanasi, Uttar Pradesh",      "2026-03-12T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Lanka, Varanasi. NCRB Table 1-10.",          25.2700, 82.9900, "Lanka, Varanasi, Uttar Pradesh",              "2026-03-14T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Jhansi city. 445 total victims. NCRB 1-10.", 25.4484, 78.5685, "Jhansi City, Jhansi, Uttar Pradesh",          "2026-03-16T10:00:00", "MEDIUM"));
        list.add(c("Kidnapping",  "Kidnapping victims in Sipri Bazar, Jhansi. NCRB 1-10.",         25.4600, 78.5800, "Sipri Bazar, Jhansi, Uttar Pradesh",          "2026-03-18T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Ghaziabad city. 446 total victims. NCRB 1-10.",28.6692, 77.4538, "Ghaziabad City, Ghaziabad, Uttar Pradesh",  "2026-03-20T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Loni, Ghaziabad. NCRB Table 1-10.",          28.7500, 77.2900, "Loni, Ghaziabad, Uttar Pradesh",              "2026-03-22T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Prayagraj city. 405 total victims. NCRB 1-10.",25.4358, 81.8463, "Prayagraj City, Prayagraj, Uttar Pradesh",  "2026-03-24T10:00:00", "HIGH"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim UP: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataGujarat2() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Ahmedabad city. 3,943 total victims. NCRB 1-10.",23.0225, 72.5714, "Ahmedabad City, Ahmedabad, Gujarat",      "2026-03-01T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Naroda, Ahmedabad. NCRB Table 1-10.",        23.0700, 72.6500, "Naroda, Ahmedabad, Gujarat",                  "2026-03-03T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Odhav, Ahmedabad. NCRB Table 1-10.",      23.0400, 72.6700, "Odhav, Ahmedabad, Gujarat",                   "2026-03-05T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Gota, Ahmedabad. NCRB Table 1-10.",          23.1000, 72.5400, "Gota, Ahmedabad, Gujarat",                    "2026-03-07T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Surat city. 2,680 total victims. NCRB 1-10.", 21.1702, 72.8311, "Surat City, Surat, Gujarat",                  "2026-03-09T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Limbayat, Surat. NCRB Table 1-10.",          21.1900, 72.8600, "Limbayat, Surat, Gujarat",                    "2026-03-11T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Udhna, Surat. NCRB Table 1-10.",          21.1600, 72.8700, "Udhna, Surat, Gujarat",                       "2026-03-13T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Rajkot city. 711 total victims. NCRB 1-10.",  22.3039, 70.8022, "Rajkot City, Rajkot, Gujarat",                "2026-03-15T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Kalawad Road, Rajkot. NCRB 1-10.",           22.3200, 70.7800, "Kalawad Road, Rajkot, Gujarat",               "2026-03-17T10:00:00", "MEDIUM"));
        list.add(c("Assault",     "Assault victims in Gandhinagar city. 712 total victims.",       23.2156, 72.6369, "Gandhinagar City, Gandhinagar, Gujarat",      "2026-03-19T10:00:00", "MEDIUM"));
        list.add(c("Kidnapping",  "Kidnapping victims in Sector 21, Gandhinagar. NCRB 1-10.",      23.2200, 72.6500, "Sector 21, Gandhinagar, Gujarat",             "2026-03-21T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Vadodara city. 594 total victims. NCRB 1-10.",22.3072, 73.1812, "Vadodara City, Vadodara, Gujarat",            "2026-03-23T10:00:00", "MEDIUM"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim Gujarat: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataDelhi2() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Outer North Delhi. 2,721 total victims.",     28.7900, 77.1200, "Outer North Delhi, Delhi",                    "2026-03-01T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Alipur, Outer North Delhi. NCRB 1-10.",      28.8200, 77.1300, "Alipur, Outer North Delhi, Delhi",            "2026-03-03T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Badli, Outer North Delhi. NCRB 1-10.",    28.7500, 77.1500, "Badli, Outer North Delhi, Delhi",             "2026-03-05T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in North-East Delhi. 2,362 total victims.",      28.6800, 77.3000, "North-East Delhi, Delhi",                     "2026-03-07T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Mustafabad, North-East Delhi. NCRB 1-10.",   28.7000, 77.3100, "Mustafabad, North-East Delhi, Delhi",         "2026-03-09T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Seelampur, North-East Delhi. NCRB 1-10.", 28.6600, 77.2800, "Seelampur, North-East Delhi, Delhi",          "2026-03-11T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Rohini, Delhi. 1,797 total victims. NCRB 1-10.",28.7041, 77.1025, "Rohini, Delhi",                            "2026-03-13T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Prashant Vihar, Rohini. NCRB 1-10.",         28.7200, 77.1300, "Prashant Vihar, Rohini, Delhi",               "2026-03-15T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in South Delhi. 1,563 total victims. NCRB 1-10.",28.5244, 77.2066, "South Delhi, Delhi",                          "2026-03-17T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Mehrauli, South Delhi. NCRB 1-10.",          28.5200, 77.1900, "Mehrauli, South Delhi, Delhi",                "2026-03-19T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Dwarka, Delhi. 2,109 total victims. NCRB 1-10.",28.5921, 77.0460, "Dwarka, Delhi",                            "2026-03-21T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Uttam Nagar, Dwarka. NCRB 1-10.",            28.6200, 77.0600, "Uttam Nagar, Dwarka, Delhi",                  "2026-03-23T10:00:00", "MEDIUM"));
        list.add(c("Kidnapping",  "Kidnapping victims in Bindapur, Dwarka. NCRB 1-10.",            28.6000, 77.0500, "Bindapur, Dwarka, Delhi",                     "2026-03-25T10:00:00", "MEDIUM"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim Delhi: inserted " + list.size() + " records.");
    }

    private void seedNCRBVictimDataMaharashtra2() {
        List<Crime> list = new ArrayList<>();
        list.add(c("Murder",      "Murder victims in Dharavi, Mumbai. 8,964 total victims. NCRB 1-10.",19.0400, 72.8530, "Dharavi, Mumbai, Maharashtra",           "2026-03-01T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Mankhurd, Mumbai. NCRB Table 1-10.",          19.0500, 72.9300, "Mankhurd, Mumbai, Maharashtra",               "2026-03-03T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Ghatkopar, Mumbai. NCRB Table 1-10.",      19.0860, 72.9081, "Ghatkopar, Mumbai, Maharashtra",              "2026-03-05T10:00:00", "HIGH"));
        list.add(c("Robbery",     "Robbery victims in Chembur, Mumbai. NCRB Table 1-10.",           19.0522, 72.8994, "Chembur, Mumbai, Maharashtra",                "2026-03-07T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Vikhroli, Mumbai. NCRB Table 1-10.",           19.1000, 72.9200, "Vikhroli, Mumbai, Maharashtra",               "2026-03-09T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Thane city. 4,939 total victims. NCRB 1-10.",  19.2183, 72.9781, "Thane City, Thane, Maharashtra",              "2026-03-11T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Mumbra, Thane. NCRB Table 1-10.",             19.1800, 73.0200, "Mumbra, Thane, Maharashtra",                  "2026-03-13T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Bhiwandi, Thane. NCRB Table 1-10.",        19.2967, 73.0631, "Bhiwandi, Thane, Maharashtra",                "2026-03-15T10:00:00", "HIGH"));
        list.add(c("Murder",      "Murder victims in Pune city. 2,970 total victims. NCRB 1-10.",   18.5314, 73.8446, "Pune City, Pune, Maharashtra",                "2026-03-17T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Kondhwa, Pune. NCRB Table 1-10.",             18.4700, 73.8900, "Kondhwa, Pune, Maharashtra",                  "2026-03-19T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Yerawada, Pune. NCRB Table 1-10.",         18.5500, 73.9000, "Yerawada, Pune, Maharashtra",                 "2026-03-21T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Nagpur city. 3,072 total victims. NCRB 1-10.", 21.1458, 79.0882, "Nagpur City, Nagpur, Maharashtra",            "2026-03-23T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Nandanvan, Nagpur. NCRB Table 1-10.",         21.1300, 79.1000, "Nandanvan, Nagpur, Maharashtra",              "2026-03-25T10:00:00", "HIGH"));
        list.add(c("Kidnapping",  "Kidnapping victims in Kamptee, Nagpur. NCRB Table 1-10.",        21.2200, 79.1900, "Kamptee, Nagpur, Maharashtra",                "2026-03-27T10:00:00", "MEDIUM"));
        list.add(c("Murder",      "Murder victims in Pimpri Chinchwad. 3,050 total victims.",       18.6298, 73.7997, "Pimpri Chinchwad, Pune, Maharashtra",         "2026-03-29T10:00:00", "HIGH"));
        list.add(c("Assault",     "Assault victims in Chinchwad, Pune. NCRB Table 1-10.",           18.6400, 73.8000, "Chinchwad, Pune, Maharashtra",                "2026-03-31T10:00:00", "HIGH"));
        repo.saveAll(list);
        System.out.println("[DataSeeder] NCRB Victim Maharashtra: inserted " + list.size() + " records.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HELPER
    // ══════════════════════════════════════════════════════════════════════════
    private Crime c(String type, String desc, double lat, double lng,
                    String location, String dateTime, String severity) {
        Crime cr = new Crime();
        cr.setType(type);
        cr.setDescription(desc);
        cr.setLatitude(lat);
        cr.setLongitude(lng);
        cr.setLocation(location);
        cr.setCrimeDate(LocalDateTime.parse(dateTime));
        cr.setSeverity(severity);
        return cr;
    }
}
