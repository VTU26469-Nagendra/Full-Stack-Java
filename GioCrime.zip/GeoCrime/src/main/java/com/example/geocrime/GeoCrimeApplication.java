package com.example.geocrime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeoCrimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeoCrimeApplication.class, args);
	}

}
