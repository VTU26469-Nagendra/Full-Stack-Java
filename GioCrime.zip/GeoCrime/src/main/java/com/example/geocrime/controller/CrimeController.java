package com.example.geocrime.controller;

import com.example.geocrime.model.Crime;
import com.example.geocrime.service.CrimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/crimes")
@CrossOrigin
public class CrimeController {

    @Autowired
    private CrimeService crimeService;

    // GET all crimes
    @GetMapping
    public List<Crime> getAllCrimes() {
        return crimeService.getAllCrimes();
    }

    // GET single crime
    @GetMapping("/{id}")
    public ResponseEntity<Crime> getCrimeById(@PathVariable int id) {
        return crimeService.getCrimeById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET filtered crimes
    @GetMapping("/filter")
    public List<Crime> filterCrimes(
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        return crimeService.filterCrimes(type, location, startDate, endDate);
    }

    // GET analytics
    @GetMapping("/analytics")
    public Map<String, Object> getAnalytics() {
        return crimeService.getAnalytics();
    }

    // POST add crime (admin only — enforced in SecurityConfig)
    @PostMapping
    public ResponseEntity<Crime> addCrime(@RequestBody Crime crime) {
        Crime saved = crimeService.saveCrime(crime);
        return ResponseEntity.ok(saved);
    }

    // PUT update crime (admin only)
    @PutMapping("/{id}")
    public ResponseEntity<Crime> updateCrime(@PathVariable int id, @RequestBody Crime crime) {
        return crimeService.getCrimeById(id).map(existing -> {
            crime.setCrimeId(id);
            return ResponseEntity.ok(crimeService.saveCrime(crime));
        }).orElse(ResponseEntity.notFound().build());
    }

    // DELETE crime (admin only)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCrime(@PathVariable int id) {
        crimeService.deleteCrime(id);
        return ResponseEntity.noContent().build();
    }
}
