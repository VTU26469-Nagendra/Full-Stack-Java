package com.example.geocrime.model;

/**
 * Broadcast payload sent over WebSocket to all connected clients.
 * action: ADDED | UPDATED | DELETED
 */
public class CrimeEvent {

    private String action;   // "ADDED", "UPDATED", "DELETED"
    private Crime  crime;    // null for DELETED
    private Integer crimeId; // set for DELETED

    public CrimeEvent() {}

    public CrimeEvent(String action, Crime crime) {
        this.action  = action;
        this.crime   = crime;
        this.crimeId = crime != null ? crime.getCrimeId() : null;
    }

    public CrimeEvent(String action, int crimeId) {
        this.action  = action;
        this.crimeId = crimeId;
    }

    public String  getAction()  { return action; }
    public Crime   getCrime()   { return crime; }
    public Integer getCrimeId() { return crimeId; }

    public void setAction(String action)   { this.action  = action; }
    public void setCrime(Crime crime)      { this.crime   = crime; }
    public void setCrimeId(Integer id)     { this.crimeId = id; }
}
