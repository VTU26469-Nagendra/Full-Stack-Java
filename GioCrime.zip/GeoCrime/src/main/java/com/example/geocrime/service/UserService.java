package com.example.geocrime.service;

import com.example.geocrime.model.User;
import com.example.geocrime.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Map<String, String> register(String username, String rawPassword) {
        if (userRepo.findByUsername(username).isPresent()) {
            return Map.of("status", "error", "message", "Username already exists");
        }
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setRole("USER");
        userRepo.save(user);
        return Map.of("status", "success", "message", "Registration successful");
    }

    public boolean isUsernameAvailable(String username) {
        return userRepo.findByUsername(username).isEmpty();
    }
}
