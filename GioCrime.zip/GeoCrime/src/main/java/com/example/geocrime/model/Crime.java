package com.example.geocrime.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "crimes", indexes = {
    @Index(name = "idx_location", columnList = "location_name"),
    @Index(name = "idx_date", columnList = "crime_date"),
    @Index(name = "idx_type", columnList = "type")
})
public class Crime {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int crimeId;

    @Column(nullable = false, length = 50)
    private String type;

    @Column(name = "location_name", length = 150)
    private String location;

    @Column(nullable = false)
    private double latitude;

    @Column(nullable = false)
    private double longitude;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "crime_date")
    private LocalDateTime crimeDate;

    @Column(length = 100)
    private String severity; // LOW, MEDIUM, HIGH

    // ── Getters & Setters ──────────────────────────────────────────────────────

    public int getCrimeId() { return crimeId; }
    public void setCrimeId(int crimeId) { this.crimeId = crimeId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public LocalDateTime getCrimeDate() { return crimeDate; }
    public void setCrimeDate(LocalDateTime crimeDate) { this.crimeDate = crimeDate; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }
}