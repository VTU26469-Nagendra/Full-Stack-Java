package com.example.geocrime.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.geocrime.model.Crime;

import java.time.LocalDateTime;
import java.util.List;

public interface CrimeRepository extends JpaRepository<Crime, Integer> {

    List<Crime> findByType(String type);

    List<Crime> findByLocationContainingIgnoreCase(String location);

    List<Crime> findByCrimeDateBetween(LocalDateTime start, LocalDateTime end);

    List<Crime> findByTypeAndCrimeDateBetween(String type, LocalDateTime start, LocalDateTime end);

    @Query("SELECT c.type, COUNT(c) FROM Crime c GROUP BY c.type ORDER BY COUNT(c) DESC")
    List<Object[]> countByType();

    @Query("SELECT c.location, COUNT(c) FROM Crime c GROUP BY c.location ORDER BY COUNT(c) DESC")
    List<Object[]> countByLocation();

    @Query("SELECT FUNCTION('YEAR', c.crimeDate), FUNCTION('MONTH', c.crimeDate), COUNT(c) " +
           "FROM Crime c WHERE c.crimeDate IS NOT NULL " +
           "GROUP BY FUNCTION('YEAR', c.crimeDate), FUNCTION('MONTH', c.crimeDate) " +
           "ORDER BY FUNCTION('YEAR', c.crimeDate), FUNCTION('MONTH', c.crimeDate)")
    List<Object[]> countByMonth();

    @Query("SELECT c.severity, COUNT(c) FROM Crime c GROUP BY c.severity")
    List<Object[]> countBySeverity();

    @Query("SELECT c FROM Crime c WHERE " +
           "(:type IS NULL OR c.type = :type) AND " +
           "(:location IS NULL OR LOWER(c.location) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
           "(:startDate IS NULL OR c.crimeDate >= :startDate) AND " +
           "(:endDate IS NULL OR c.crimeDate <= :endDate)")
    List<Crime> filterCrimes(@Param("type") String type,
                              @Param("location") String location,
                              @Param("startDate") LocalDateTime startDate,
                              @Param("endDate") LocalDateTime endDate);
}