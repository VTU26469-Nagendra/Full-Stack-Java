# GeoCrime - Quick Setup Guide

## ⚡ Quick Start (5 Minutes)

### Step 1: Setup MySQL Database (2 minutes)

1. **Open MySQL Command Line or MySQL Workbench**

2. **Create Database:**
```sql
CREATE DATABASE geocrime CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

3. **Import Schema & Data:**
```sql
USE geocrime;
SOURCE C:/Users/Nagendra/eclipse-workspace/GeoCrime/src/main/resources/schema.sql;
```

Or copy-paste the contents of `src/main/resources/schema.sql` into MySQL Workbench and execute.

4. **Verify Data:**
```sql
SELECT COUNT(*) FROM crimes;  -- Should return 53
SELECT COUNT(*) FROM users;   -- Should return 2
```

### Step 2: Configure Application (1 minute)

Open `src/main/resources/application.properties` and update your MySQL password:

```properties
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

Replace `YOUR_MYSQL_PASSWORD` with your actual MySQL root password.

### Step 3: Run the Application (2 minutes)

#### Option A: Using Eclipse IDE
1. Right-click on project → Run As → Spring Boot App
2. Wait for "Started GeoCrimeApplication" message in console

#### Option B: Using Command Line (Windows)
```bash
cd C:\Users\Nagendra\eclipse-workspace\GeoCrime
mvnw.cmd spring-boot:run
```

#### Option C: Using Command Line (Linux/Mac)
```bash
cd /path/to/GeoCrime
./mvnw spring-boot:run
```

### Step 4: Access the Application

Open your browser and navigate to:

- **User Dashboard**: http://localhost:8080/index.html
- **Admin Panel**: http://localhost:8080/admin.html
- **Login Page**: http://localhost:8080/user-login.html

### Step 5: Login

Use these credentials:

**Admin Account:**
- Username: `admin`
- Password: `admin123`

**User Account:**
- Username: `user`
- Password: `user123`

---

## 🎯 What to Test

### User Dashboard (index.html)
1. ✅ View crime statistics on dashboard
2. ✅ Explore interactive crime map
3. ✅ Toggle heatmap visualization
4. ✅ Filter crimes by type, location, date
5. ✅ View analytics charts
6. ✅ Check high-crime zone alerts
7. ✅ Browse crime list table

### Admin Panel (admin.html)
1. ✅ View admin overview statistics
2. ✅ Add new crime record
3. ✅ Click on map to set coordinates
4. ✅ Edit existing crime records
5. ✅ Delete crime records
6. ✅ View live map with all crimes
7. ✅ Test real-time updates (open in 2 tabs)

### Real-time Features
1. Open admin panel in one browser tab
2. Open user dashboard in another tab
3. Add/edit/delete a crime in admin panel
4. Watch the user dashboard update automatically!
5. You should see toast notifications

---

## 🔧 Troubleshooting

### Problem: "Port 8080 already in use"

**Solution 1:** Stop the process using port 8080
```bash
# Windows
netstat -ano | findstr :8080
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:8080 | xargs kill -9
```

**Solution 2:** Change the port in `application.properties`
```properties
server.port=8081
```

### Problem: "Cannot connect to database"

**Check 1:** Is MySQL running?
```bash
# Windows
services.msc  # Look for MySQL service

# Linux
sudo systemctl status mysql
```

**Check 2:** Can you connect manually?
```bash
mysql -u root -p
```

**Check 3:** Is the password correct in `application.properties`?

### Problem: "Table 'geocrime.crimes' doesn't exist"

**Solution:** Re-import the schema
```sql
USE geocrime;
SOURCE /path/to/schema.sql;
```

### Problem: "WebSocket connection failed"

**Solution 1:** Clear browser cache and reload

**Solution 2:** Check browser console for errors (F12)

**Solution 3:** Verify WebSocket endpoint is accessible:
- Open browser console
- Try: `new WebSocket('ws://localhost:8080/ws')`

### Problem: Eclipse shows compilation errors

**Solution:**
1. Right-click project → Maven → Update Project
2. Check "Force Update of Snapshots/Releases"
3. Click OK
4. Project → Clean → Clean All Projects
5. Restart Eclipse if needed

---

## 📊 Sample Data Overview

The database includes **53 crime records** from Karnataka:

| City       | Records | Crime Types                                    |
|------------|---------|------------------------------------------------|
| Bangalore  | 20      | Theft, Cyber Crime, Assault, Burglary, etc.   |
| Mysore     | 10      | Theft, Burglary, Assault, Fraud, etc.          |
| Hubli      | 8       | Theft, Burglary, Assault, Fraud, etc.          |
| Mangalore  | 7       | Theft, Burglary, Assault, Fraud, Cyber Crime   |
| Belgaum    | 5       | Theft, Burglary, Assault, Fraud                |
| Davangere  | 3       | Theft, Burglary, Assault                       |

**Crime Types:**
- Theft (most common)
- Assault
- Robbery
- Burglary
- Vandalism
- Fraud
- Murder
- Kidnapping
- Cyber Crime

**Severity Levels:**
- HIGH - Serious crimes (Murder, Kidnapping, Armed Robbery)
- MEDIUM - Moderate crimes (Theft, Assault, Fraud)
- LOW - Minor crimes (Vandalism, Petty Theft)

---

## 🎨 UI Features to Explore

### Dashboard
- **Animated Counters** - Watch numbers count up
- **Interactive Charts** - Hover to see details
- **Real-time Clock** - Live time display
- **Live Status Indicator** - Green dot shows connection

### Crime Map
- **Marker Clustering** - Zoom in to see individual crimes
- **Color-Coded Markers** - Each crime type has unique color
- **Heatmap Toggle** - Click "Heatmap" button
- **Popup Details** - Click markers for crime info
- **Filters** - Filter by type, location, date range

### Admin Panel
- **Map Picker** - Click map to set coordinates
- **Edit Modal** - Smooth popup for editing
- **Toast Notifications** - Success/error messages
- **Real-time Sync** - Changes appear instantly

---

## 🔐 Security Notes

### Password Hashing
- All passwords are hashed using BCrypt
- Never store plain text passwords
- Default password: `admin123` / `user123`

### Change Default Passwords
```sql
-- Generate new BCrypt hash at: https://bcrypt-generator.com/
UPDATE users SET password = '$2a$10$NEW_HASH_HERE' WHERE username = 'admin';
```

### Role-Based Access
- **ADMIN** - Full access (CRUD operations)
- **USER** - Read-only access (view data)

---

## 📱 Browser Compatibility

✅ **Supported Browsers:**
- Chrome 90+
- Firefox 88+
- Edge 90+
- Safari 14+
- Opera 76+

❌ **Not Supported:**
- Internet Explorer (any version)
- Chrome < 90
- Firefox < 88

---

## 🚀 Next Steps

### Add More Data
1. Open admin panel
2. Click "Add Crime"
3. Fill in details
4. Click map to set location
5. Save

### Customize
- Edit `style.css` for theme changes
- Modify `application.properties` for config
- Update `schema.sql` for more sample data

### Deploy
1. Build JAR: `mvnw clean package`
2. Run: `java -jar target/geocrime-0.0.1-SNAPSHOT.jar`
3. Deploy to cloud (AWS, Azure, Heroku)

---

## 📞 Need Help?

1. Check console logs (F12 in browser)
2. Check Spring Boot logs in terminal
3. Verify MySQL connection
4. Review `README.md` for detailed docs
5. Open an issue on GitHub

---

**Happy Crime Mapping! 🗺️🔍**
