-- ============================================================================
-- Fix GeoCrime Database - Check and Recreate Tables
-- ============================================================================

USE geocrime;

-- Show current table structure
DESCRIBE crimes;
DESCRIBE users;

-- Drop and recreate tables with correct structure
DROP TABLE IF EXISTS crimes;
DROP TABLE IF EXISTS users;

-- Create Users Table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create Crimes Table
CREATE TABLE crimes (
    crime_id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    location VARCHAR(255) NOT NULL,
    crime_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    severity VARCHAR(20) DEFAULT 'MEDIUM',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_location (location),
    INDEX idx_crime_date (crime_date),
    INDEX idx_severity (severity),
    INDEX idx_lat_lng (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert Users
INSERT INTO users (username, password, role) VALUES
('admin', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ADMIN'),
('user', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'USER');

-- Insert ALL Crime Data
INSERT INTO crimes (type, description, latitude, longitude, location, crime_date, severity) VALUES
-- Bangalore
('Theft', 'Mobile phone theft near metro station', 12.9716, 77.5946, 'MG Road, Bangalore', '2026-01-15 14:30:00', 'MEDIUM'),
('Cyber Crime', 'Online banking fraud reported', 12.9352, 77.6245, 'Koramangala, Bangalore', '2026-01-18 10:15:00', 'HIGH'),
('Assault', 'Physical altercation outside bar', 12.9698, 77.7499, 'Whitefield, Bangalore', '2026-01-20 23:45:00', 'HIGH'),
('Burglary', 'House break-in during daytime', 13.0358, 77.5970, 'Yelahanka, Bangalore', '2026-01-22 11:00:00', 'HIGH'),
('Theft', 'Two-wheeler theft from parking lot', 12.9141, 77.6411, 'BTM Layout, Bangalore', '2026-01-25 16:20:00', 'MEDIUM'),
('Fraud', 'Real estate fraud case filed', 12.9279, 77.6271, 'HSR Layout, Bangalore', '2026-01-28 09:30:00', 'HIGH'),
('Vandalism', 'Public property damage reported', 12.9634, 77.6401, 'Indiranagar, Bangalore', '2026-02-01 02:15:00', 'LOW'),
('Robbery', 'Armed robbery at jewelry store', 12.9716, 77.5946, 'Commercial Street, Bangalore', '2026-02-03 19:30:00', 'HIGH'),
('Kidnapping', 'Minor child kidnapping case', 13.0827, 77.5877, 'Hebbal, Bangalore', '2026-02-05 15:45:00', 'HIGH'),
('Theft', 'Laptop theft from office premises', 12.9352, 77.6245, 'Koramangala, Bangalore', '2026-02-08 18:00:00', 'MEDIUM'),
('Assault', 'Domestic violence case reported', 12.9141, 77.6411, 'BTM Layout, Bangalore', '2026-02-10 21:30:00', 'MEDIUM'),
('Cyber Crime', 'Social media account hacking', 12.9698, 77.7499, 'Whitefield, Bangalore', '2026-02-12 13:20:00', 'MEDIUM'),
('Burglary', 'Shop break-in at night', 12.9279, 77.6271, 'HSR Layout, Bangalore', '2026-02-14 03:45:00', 'HIGH'),
('Theft', 'Gold chain snatching incident', 12.9716, 77.5946, 'MG Road, Bangalore', '2026-02-16 12:00:00', 'HIGH'),
('Fraud', 'Credit card fraud detected', 12.9634, 77.6401, 'Indiranagar, Bangalore', '2026-02-18 10:30:00', 'MEDIUM'),
('Vandalism', 'Vehicle vandalism in parking area', 13.0358, 77.5970, 'Yelahanka, Bangalore', '2026-02-20 01:15:00', 'LOW'),
('Robbery', 'Street robbery near bus stop', 12.9141, 77.6411, 'BTM Layout, Bangalore', '2026-02-22 20:45:00', 'HIGH'),
('Theft', 'Bicycle theft from residential area', 12.9352, 77.6245, 'Koramangala, Bangalore', '2026-02-24 07:30:00', 'LOW'),
('Assault', 'Road rage incident reported', 12.9698, 77.7499, 'Whitefield, Bangalore', '2026-02-26 17:00:00', 'MEDIUM'),
('Cyber Crime', 'Phishing scam targeting seniors', 12.9279, 77.6271, 'HSR Layout, Bangalore', '2026-02-28 11:45:00', 'HIGH'),
-- Mysore
('Theft', 'Tourist bag theft near palace', 12.3052, 76.6550, 'Mysore Palace Area, Mysore', '2026-01-16 15:00:00', 'MEDIUM'),
('Burglary', 'Residential burglary reported', 12.2958, 76.6394, 'Vijayanagar, Mysore', '2026-01-21 04:30:00', 'HIGH'),
('Assault', 'Bar fight escalated to assault', 12.3051, 76.6553, 'Devaraja Market, Mysore', '2026-01-26 22:00:00', 'MEDIUM'),
('Theft', 'Auto-rickshaw theft case', 12.2711, 76.6411, 'Hebbal, Mysore', '2026-02-02 08:15:00', 'MEDIUM'),
('Fraud', 'Insurance fraud investigation', 12.3052, 76.6550, 'Saraswathipuram, Mysore', '2026-02-07 14:30:00', 'HIGH'),
('Vandalism', 'Graffiti on public walls', 12.2958, 76.6394, 'Kuvempunagar, Mysore', '2026-02-11 01:00:00', 'LOW'),
('Robbery', 'Petrol pump robbery attempt', 12.3051, 76.6553, 'Ring Road, Mysore', '2026-02-15 23:30:00', 'HIGH'),
('Theft', 'Mobile phone snatching', 12.2711, 76.6411, 'Chamundi Hill Road, Mysore', '2026-02-19 16:45:00', 'MEDIUM'),
('Assault', 'Workplace assault incident', 12.3052, 76.6550, 'Industrial Area, Mysore', '2026-02-23 10:00:00', 'MEDIUM'),
('Cyber Crime', 'Online shopping fraud', 12.2958, 76.6394, 'Gokulam, Mysore', '2026-02-27 12:30:00', 'MEDIUM'),
-- Hubli
('Theft', 'Shop theft during business hours', 15.3647, 75.1240, 'Old Hubli, Hubli', '2026-01-17 13:00:00', 'MEDIUM'),
('Burglary', 'Warehouse break-in', 15.3173, 75.1240, 'Gokul Road, Hubli', '2026-01-23 02:45:00', 'HIGH'),
('Assault', 'Street fight reported', 15.3647, 75.1240, 'Unkal Lake Area, Hubli', '2026-01-29 19:15:00', 'MEDIUM'),
('Theft', 'Vehicle parts theft', 15.3173, 75.1240, 'Vidyanagar, Hubli', '2026-02-04 05:30:00', 'MEDIUM'),
('Fraud', 'Land fraud case filed', 15.3647, 75.1240, 'Navanagar, Hubli', '2026-02-09 11:00:00', 'HIGH'),
('Robbery', 'Bank ATM robbery attempt', 15.3173, 75.1240, 'Keshwapur, Hubli', '2026-02-13 22:45:00', 'HIGH'),
('Vandalism', 'Bus stop vandalism', 15.3647, 75.1240, 'Hosur, Hubli', '2026-02-17 03:00:00', 'LOW'),
('Theft', 'Cattle theft from farm', 15.3173, 75.1240, 'Amargol, Hubli', '2026-02-21 06:15:00', 'MEDIUM'),
-- Mangalore
('Theft', 'Beach visitor belongings theft', 12.9141, 74.8560, 'Panambur Beach, Mangalore', '2026-01-19 17:30:00', 'MEDIUM'),
('Burglary', 'Hotel room burglary', 12.8698, 74.8430, 'Hampankatta, Mangalore', '2026-01-24 03:15:00', 'HIGH'),
('Assault', 'Pub assault incident', 12.9141, 74.8560, 'Kadri, Mangalore', '2026-01-30 23:00:00', 'MEDIUM'),
('Theft', 'Fishing equipment theft', 12.8698, 74.8430, 'Bunder, Mangalore', '2026-02-06 07:45:00', 'LOW'),
('Fraud', 'Export-import fraud case', 12.9141, 74.8560, 'Port Area, Mangalore', '2026-02-11 15:00:00', 'HIGH'),
('Robbery', 'Jewelry shop robbery', 12.8698, 74.8430, 'Car Street, Mangalore', '2026-02-16 18:30:00', 'HIGH'),
('Cyber Crime', 'Email phishing scam', 12.9141, 74.8560, 'Bejai, Mangalore', '2026-02-25 09:00:00', 'MEDIUM'),
-- Belgaum
('Theft', 'Market area pickpocketing', 15.8497, 74.4977, 'Khade Bazaar, Belgaum', '2026-01-27 14:00:00', 'MEDIUM'),
('Burglary', 'Office burglary at night', 15.8497, 74.4977, 'Tilakwadi, Belgaum', '2026-02-01 04:00:00', 'HIGH'),
('Assault', 'Political rally violence', 15.8497, 74.4977, 'Congress Bhavan Area, Belgaum', '2026-02-08 16:30:00', 'HIGH'),
('Theft', 'Agricultural equipment theft', 15.8497, 74.4977, 'Hindalga, Belgaum', '2026-02-14 06:00:00', 'MEDIUM'),
('Fraud', 'Cooperative bank fraud', 15.8497, 74.4977, 'Camp Area, Belgaum', '2026-02-20 10:30:00', 'HIGH'),
-- Davangere
('Theft', 'Cotton bales theft from godown', 14.4644, 75.9218, 'APMC Yard, Davangere', '2026-02-03 05:00:00', 'HIGH'),
('Burglary', 'Residential break-in', 14.4644, 75.9218, 'PJ Extension, Davangere', '2026-02-12 02:30:00', 'HIGH'),
('Assault', 'Family dispute turned violent', 14.4644, 75.9218, 'Shamanur Road, Davangere', '2026-02-22 20:00:00', 'MEDIUM');

-- Verify import
SELECT 'Import Complete!' as Status;
SELECT COUNT(*) as total_users FROM users;
SELECT COUNT(*) as total_crimes FROM crimes;
SELECT type, COUNT(*) as count FROM crimes GROUP BY type ORDER BY count DESC;
