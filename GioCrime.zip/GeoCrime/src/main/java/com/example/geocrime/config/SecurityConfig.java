package com.example.geocrime.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())

            .authorizeHttpRequests(auth -> auth

                // ── Public static pages & WebSocket ─────────────────────────
                .requestMatchers(
                    "/", "/index.html", "/user-login.html", "/login.html",
                    "/register.html", "/style.css", "/dashboard.html",
                    "/*.js", "/*.css", "/*.ico",
                    "/ws/**"          // WebSocket SockJS endpoint
                ).permitAll()

                // ── Public API endpoints ─────────────────────────────────────
                .requestMatchers(HttpMethod.GET,  "/api/crimes").permitAll()
                .requestMatchers(HttpMethod.GET,  "/api/crimes/filter").permitAll()
                .requestMatchers(HttpMethod.GET,  "/api/crimes/analytics").permitAll()
                .requestMatchers(HttpMethod.GET,  "/api/crimes/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/users/register").permitAll()
                .requestMatchers(HttpMethod.GET,  "/api/users/check-username").permitAll()

                // ── Admin-only API mutations ─────────────────────────────────
                .requestMatchers(HttpMethod.POST,   "/api/crimes").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT,    "/api/crimes/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/crimes/**").hasRole("ADMIN")

                // ── Role-based pages ─────────────────────────────────────────
                .requestMatchers("/admin.html").hasRole("ADMIN")

                // Everything else requires authentication
                .anyRequest().authenticated()
            )

            .formLogin(form -> form
                .loginPage("/user-login.html")
                .loginProcessingUrl("/login")
                .successHandler((request, response, authentication) -> {
                    boolean isAdmin = authentication.getAuthorities().stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
                    if (isAdmin) {
                        response.sendRedirect("/admin.html");
                    } else {
                        response.sendRedirect("/index.html");
                    }
                })
                .failureHandler(loginFailureHandler())
                .permitAll()
            )

            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/user-login.html?logout=true")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            );

        return http.build();
    }

    @Bean
    public AuthenticationFailureHandler loginFailureHandler() {
        return (HttpServletRequest request, HttpServletResponse response,
                AuthenticationException exception) -> {
            // Check where the login form was submitted from
            String referer = request.getHeader("Referer");
            if (referer != null && referer.contains("login.html")) {
                // Admin login page — redirect back to admin login with error
                response.sendRedirect("/login.html?error=true");
            } else {
                // User login page — redirect back to user login with error
                response.sendRedirect("/user-login.html?error=true");
            }
        };
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
